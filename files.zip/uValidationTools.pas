unit uValidationTools;

interface

uses
  System.SysUtils, System.Classes,
  Vcl.Forms, Vcl.Controls, Vcl.StdCtrls, Vcl.ComCtrls,
  Vcl.ExtCtrls, Vcl.Graphics, Vcl.Buttons,
  uDialogueTypes, uThemeManager;

type
  TValidationForm = class(TForm)
  private
    FProject: TDialogueProject;
    pnlTop: TPanel;
    lblTitle: TLabel;
    pnlBottom: TPanel;
    btnRun: TButton;
    btnClose: TButton;
    pcTools: TPageControl;
    tsValidation: TTabSheet;
    tsFlowAnalysis: TTabSheet;
    tsSearch: TTabSheet;
    lstIssues: TListView;
    memoFlowReport: TMemo;
    pnlSearchBar: TPanel;
    edtSearch: TEdit;
    btnSearch: TButton;
    cmbSearchIn: TComboBox;
    lstSearchResults: TListView;
    lblIssueCount: TLabel;
    btnFixAll: TButton;
    procedure BuildLayout;
    procedure StyleForm;
    procedure RunValidation;
    procedure RunFlowAnalysis;
    procedure RunSearch;
    procedure btnRunClick(Sender: TObject);
    procedure btnCloseClick(Sender: TObject);
    procedure btnSearchClick(Sender: TObject);
    procedure btnFixAllClick(Sender: TObject);
    procedure lstIssuesDblClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormShow(Sender: TObject);
  public
    class procedure Execute(AOwner: TComponent; aProject: TDialogueProject);
    property OnNodeSelected: TProc<string> read FOnNodeSelected write FOnNodeSelected;
  private
    FOnNodeSelected: TProc<string>;
  end;

implementation

class procedure TValidationForm.Execute(AOwner: TComponent; aProject: TDialogueProject);
var frm: TValidationForm;
begin
  frm := TValidationForm.Create(AOwner);
  try
    frm.FProject := aProject;
    frm.ShowModal;
  finally frm.Free; end;
end;

procedure TValidationForm.FormCreate(Sender: TObject);
begin BuildLayout; StyleForm; end;

procedure TValidationForm.FormShow(Sender: TObject);
begin RunValidation; end;

procedure TValidationForm.BuildLayout;
begin
  Width := 760; Height := 560;
  Caption := 'Validation & Analysis Tools';
  Position := poMainFormCenter;
  OnCreate := FormCreate; OnShow := FormShow;

  pnlTop := TPanel.Create(Self); pnlTop.Parent := Self;
  pnlTop.Align := alTop; pnlTop.Height := 40; pnlTop.BevelOuter := bvNone;
  lblTitle := TLabel.Create(Self); lblTitle.Parent := pnlTop;
  lblTitle.Left := 10; lblTitle.Top := 8;
  lblTitle.Caption := 'PROJECT VALIDATION & ANALYSIS';
  lblTitle.Font.Size := 12; lblTitle.Font.Style := [fsBold];

  pnlBottom := TPanel.Create(Self); pnlBottom.Parent := Self;
  pnlBottom.Align := alBottom; pnlBottom.Height := 42; pnlBottom.BevelOuter := bvNone;

  btnRun := TButton.Create(Self); btnRun.Parent := pnlBottom;
  btnRun.Caption := '▶ Run All Checks'; btnRun.Left := 6; btnRun.Top := 7;
  btnRun.Width := 130; btnRun.Height := 28; btnRun.OnClick := btnRunClick;

  btnFixAll := TButton.Create(Self); btnFixAll.Parent := pnlBottom;
  btnFixAll.Caption := 'Auto-Fix Warnings'; btnFixAll.Left := 142; btnFixAll.Top := 7;
  btnFixAll.Width := 130; btnFixAll.Height := 28; btnFixAll.OnClick := btnFixAllClick;

  lblIssueCount := TLabel.Create(Self); lblIssueCount.Parent := pnlBottom;
  lblIssueCount.Left := 286; lblIssueCount.Top := 12;
  lblIssueCount.Caption := 'No issues found'; lblIssueCount.Width := 200;

  btnClose := TButton.Create(Self); btnClose.Parent := pnlBottom;
  btnClose.Caption := 'Close'; btnClose.ModalResult := mrOk;
  btnClose.Anchors := [akRight, akTop];
  btnClose.Left := pnlBottom.Width - 96; btnClose.Top := 7;
  btnClose.Width := 90; btnClose.Height := 28; btnClose.OnClick := btnCloseClick;

  pcTools := TPageControl.Create(Self); pcTools.Parent := Self;
  pcTools.Align := alClient;

  tsValidation := TTabSheet.Create(pcTools);
  tsValidation.PageControl := pcTools; tsValidation.Caption := 'Validation Issues';

  lstIssues := TListView.Create(Self); lstIssues.Parent := tsValidation;
  lstIssues.Align := alClient; lstIssues.ViewStyle := vsReport;
  lstIssues.RowSelect := True; lstIssues.GridLines := True;
  lstIssues.OnDblClick := lstIssuesDblClick;
  with lstIssues.Columns.Add do begin Caption := 'Severity'; Width := 70; end;
  with lstIssues.Columns.Add do begin Caption := 'Issue'; Width := 400; end;
  with lstIssues.Columns.Add do begin Caption := 'Node ID'; Width := 160; end;

  tsFlowAnalysis := TTabSheet.Create(pcTools);
  tsFlowAnalysis.PageControl := pcTools; tsFlowAnalysis.Caption := 'Flow Analysis';
  memoFlowReport := TMemo.Create(Self); memoFlowReport.Parent := tsFlowAnalysis;
  memoFlowReport.Align := alClient; memoFlowReport.ReadOnly := True;
  memoFlowReport.ScrollBars := ssBoth; memoFlowReport.WordWrap := False;
  memoFlowReport.Font.Name := 'Courier New'; memoFlowReport.Font.Size := 9;

  tsSearch := TTabSheet.Create(pcTools);
  tsSearch.PageControl := pcTools; tsSearch.Caption := 'Search Nodes';

  pnlSearchBar := TPanel.Create(Self); pnlSearchBar.Parent := tsSearch;
  pnlSearchBar.Align := alTop; pnlSearchBar.Height := 38; pnlSearchBar.BevelOuter := bvNone;

  var searchLbl := TLabel.Create(Self); searchLbl.Parent := pnlSearchBar;
  searchLbl.Left := 4; searchLbl.Top := 10; searchLbl.Caption := 'Search:';

  edtSearch := TEdit.Create(Self); edtSearch.Parent := pnlSearchBar;
  edtSearch.Left := 56; edtSearch.Top := 7;
  edtSearch.Width := 280; edtSearch.PlaceholderText := 'Search text, IDs, tags...';

  cmbSearchIn := TComboBox.Create(Self); cmbSearchIn.Parent := pnlSearchBar;
  cmbSearchIn.Left := 344; cmbSearchIn.Top := 7;
  cmbSearchIn.Width := 160; cmbSearchIn.Style := csDropDownList;
  cmbSearchIn.Items.AddStrings(['All Fields', 'Node Text', 'Speaker', 'Node ID', 'Tag', 'Script Code']);

  btnSearch := TButton.Create(Self); btnSearch.Parent := pnlSearchBar;
  btnSearch.Caption := '🔍 Search'; btnSearch.Left := 512; btnSearch.Top := 6;
  btnSearch.Width := 90; btnSearch.Height := 26; btnSearch.OnClick := btnSearchClick;

  lstSearchResults := TListView.Create(Self); lstSearchResults.Parent := tsSearch;
  lstSearchResults.Align := alClient; lstSearchResults.ViewStyle := vsReport;
  lstSearchResults.RowSelect := True; lstSearchResults.GridLines := True;
  with lstSearchResults.Columns.Add do begin Caption := 'Node ID'; Width := 150; end;
  with lstSearchResults.Columns.Add do begin Caption := 'Type'; Width := 100; end;
  with lstSearchResults.Columns.Add do begin Caption := 'Speaker'; Width := 100; end;
  with lstSearchResults.Columns.Add do begin Caption := 'Match'; Width := 340; end;
end;

procedure TValidationForm.StyleForm;
var t: TFDCTheme;
begin
  t := TThemeManager.Current;
  Color := t.BgDark; Font.Color := t.TextPrimary; Font.Name := t.FontName;
  pnlTop.Color := t.BgMedium; pnlBottom.Color := t.BgMedium;
  lblTitle.Font.Color := t.AccentPrimary;
  lblIssueCount.Font.Color := t.TextSecondary;
  memoFlowReport.Color := t.BgDark; memoFlowReport.Font.Color := t.TextPrimary;
  lstIssues.Color := t.BgDark; lstIssues.Font.Color := t.TextPrimary;
  lstSearchResults.Color := t.BgDark; lstSearchResults.Font.Color := t.TextPrimary;
  edtSearch.Color := t.BgLight; edtSearch.Font.Color := t.TextPrimary;
  cmbSearchIn.Color := t.BgLight;
  pnlSearchBar.Color := t.BgMedium;
  pcTools.Color := t.BgDark;
end;

procedure TValidationForm.RunValidation;
var
  issues: TStringList;
  item: TListItem;
  sev, msg, nodeID: string;
  t: TFDCTheme;
begin
  if not Assigned(FProject) then Exit;
  t := TThemeManager.Current;
  lstIssues.Items.Clear;
  issues := FProject.ValidateProject;
  try
    var errCount := 0;
    var warnCount := 0;
    for var issue in issues do
    begin
      item := lstIssues.Items.Add;
      if issue.StartsWith('ERROR:') then
      begin
        sev := 'ERROR'; msg := Copy(issue, 8, MaxInt); Inc(errCount);
        item.ImageIndex := 0;
      end else if issue.StartsWith('WARNING:') then
      begin
        sev := 'WARN'; msg := Copy(issue, 10, MaxInt); Inc(warnCount);
      end else
      begin
        sev := 'INFO'; msg := issue;
      end;
      item.Caption := sev;
      item.SubItems.Add(Trim(msg));
      // Extract node ID if present
      var p := Pos('node: ', LowerCase(issue));
      if p > 0 then
        nodeID := Copy(issue, p + 6, 20)
      else
        nodeID := '';
      item.SubItems.Add(nodeID);
    end;

    if errCount > 0 then
      lblIssueCount.Caption := IntToStr(errCount) + ' error(s), ' + IntToStr(warnCount) + ' warning(s)'
    else if warnCount > 0 then
      lblIssueCount.Caption := 'No errors, ' + IntToStr(warnCount) + ' warning(s)'
    else
      lblIssueCount.Caption := '✓ All checks passed!';

    // Also run flow analysis
    RunFlowAnalysis;
  finally
    issues.Free;
  end;
end;

procedure TValidationForm.RunFlowAnalysis;
var
  node, connected: TDialogueNode;
  connList: TList<TDialogueNode>;
  visited: TDictionary<string, Boolean>;
  queue: TQueue<TDialogueNode>;
  report: TStringList;
  orphanCount, endCount, loopRisk: Integer;
begin
  if not Assigned(FProject) then Exit;
  report := TStringList.Create;
  visited := TDictionary<string, Boolean>.Create;
  queue := TQueue<TDialogueNode>.Create;
  try
    report.Add('=== DIALOGUE FLOW ANALYSIS ===');
    report.Add('Project: ' + FProject.Name);
    report.Add('Total nodes: ' + IntToStr(FProject.Nodes.Count));
    report.Add('Float messages: ' + IntToStr(FProject.FloatMessages.Count));
    report.Add('');

    // BFS from start node
    orphanCount := 0; endCount := 0; loopRisk := 0;
    if FProject.StartNodeID <> '' then
    begin
      var startNode := FProject.FindNode(FProject.StartNodeID);
      if Assigned(startNode) then
      begin
        queue.Enqueue(startNode);
        visited.Add(startNode.ID, True);
        report.Add('=== Reachability from Start Node ===');
        while queue.Count > 0 do
        begin
          node := queue.Dequeue;
          report.Add('  [' + NODE_TYPE_NAMES[node.NodeType] + '] ' + Copy(node.ID, 1, 14) +
            IfThen(node.Speaker <> '', ' (' + node.Speaker + ')', ''));
          if node.NodeType = ntEndDialogue then Inc(endCount);
          connList := FProject.GetConnectedNodes(node.ID);
          try
            for connected in connList do
              if not visited.ContainsKey(connected.ID) then
              begin
                visited.Add(connected.ID, True);
                queue.Enqueue(connected);
              end else
                Inc(loopRisk);
          finally
            connList.Free;
          end;
        end;
      end;
    end;
    report.Add('');
    report.Add('Reachable nodes: ' + IntToStr(visited.Count) + ' / ' + IntToStr(FProject.Nodes.Count));

    // Check orphans
    for node in FProject.Nodes do
      if not visited.ContainsKey(node.ID) and not node.IsStartNode then
        Inc(orphanCount);

    report.Add('Orphaned (unreachable) nodes: ' + IntToStr(orphanCount));
    report.Add('End dialogue nodes: ' + IntToStr(endCount));
    report.Add('Potential loops detected: ' + IntToStr(loopRisk));
    report.Add('');

    // Stats
    var npcCount := 0; var playerCount := 0; var condCount := 0; var scriptCount := 0;
    var totalOptions := 0; var skillCheckCount := 0;
    for node in FProject.Nodes do
    begin
      case node.NodeType of
        ntNPCDialogue:   Inc(npcCount);
        ntPlayerReply:   Inc(playerCount);
        ntConditional:   Inc(condCount);
        ntScript:        Inc(scriptCount);
      end;
      Inc(totalOptions, node.PlayerOptions.Count);
      for var opt in node.PlayerOptions do
        if opt.HasSkillCheck then Inc(skillCheckCount);
    end;

    report.Add('=== NODE TYPE BREAKDOWN ===');
    report.Add('  NPC Dialogue nodes:  ' + IntToStr(npcCount));
    report.Add('  Player Reply nodes:  ' + IntToStr(playerCount));
    report.Add('  Conditional nodes:   ' + IntToStr(condCount));
    report.Add('  Script nodes:        ' + IntToStr(scriptCount));
    report.Add('  Total player options: ' + IntToStr(totalOptions));
    report.Add('  Skill checks:        ' + IntToStr(skillCheckCount));
    report.Add('');

    if orphanCount > 0 then
    begin
      report.Add('=== ORPHANED NODES ===');
      for node in FProject.Nodes do
        if not visited.ContainsKey(node.ID) and not node.IsStartNode then
          report.Add('  ' + node.ID + '  [' + NODE_TYPE_NAMES[node.NodeType] + ']' +
            IfThen(Trim(node.Text) <> '', '  "' + Copy(node.Text, 1, 40) + '"', ''));
    end;

    memoFlowReport.Lines.Assign(report);
  finally
    report.Free;
    visited.Free;
    queue.Free;
  end;
end;

procedure TValidationForm.RunSearch;
var
  node: TDialogueNode;
  searchText: string;
  searchIn: Integer;
  item: TListItem;
  matchField, matchText: string;
  found: Boolean;

  function MatchesSearch(const s: string): Boolean;
  begin
    Result := ContainsText(s, searchText);
  end;

begin
  searchText := Trim(edtSearch.Text);
  if searchText = '' then Exit;
  searchIn := cmbSearchIn.ItemIndex;
  lstSearchResults.Items.Clear;

  for node in FProject.Nodes do
  begin
    found := False; matchField := ''; matchText := '';
    case searchIn of
      0: // All fields
      begin
        if MatchesSearch(node.Text) then begin found := True; matchField := 'Text'; matchText := node.Text; end
        else if MatchesSearch(node.Speaker) then begin found := True; matchField := 'Speaker'; matchText := node.Speaker; end
        else if MatchesSearch(node.ID) then begin found := True; matchField := 'ID'; matchText := node.ID; end
        else if MatchesSearch(node.Tag) then begin found := True; matchField := 'Tag'; matchText := node.Tag; end
        else if MatchesSearch(node.QuestID) then begin found := True; matchField := 'Quest'; matchText := node.QuestID; end;
        if not found then
          for var opt in node.PlayerOptions do
            if MatchesSearch(opt.Text) then begin found := True; matchField := 'Option'; matchText := opt.Text; Break; end;
        if not found then
          for var sc in node.Scripts do
            if MatchesSearch(sc.ScriptCode) then begin found := True; matchField := 'Script'; matchText := Copy(sc.ScriptCode, 1, 60); Break; end;
      end;
      1: if MatchesSearch(node.Text) then begin found := True; matchField := 'Text'; matchText := node.Text; end;
      2: if MatchesSearch(node.Speaker) then begin found := True; matchField := 'Speaker'; matchText := node.Speaker; end;
      3: if MatchesSearch(node.ID) then begin found := True; matchField := 'ID'; matchText := node.ID; end;
      4: if MatchesSearch(node.Tag) then begin found := True; matchField := 'Tag'; matchText := node.Tag; end;
      5: for var sc in node.Scripts do
           if MatchesSearch(sc.ScriptCode) then begin found := True; matchField := 'Script'; matchText := Copy(sc.ScriptCode, 1, 80); Break; end;
    end;

    if found then
    begin
      item := lstSearchResults.Items.Add;
      item.Caption := Copy(node.ID, 1, 16);
      item.SubItems.Add(NODE_TYPE_NAMES[node.NodeType]);
      item.SubItems.Add(node.Speaker);
      item.SubItems.Add('[' + matchField + '] ' + Copy(matchText, 1, 80));
      item.Data := node;
    end;
  end;

  lblIssueCount.Caption := 'Found: ' + IntToStr(lstSearchResults.Items.Count) + ' result(s)';
end;

procedure TValidationForm.btnRunClick(Sender: TObject); begin RunValidation; end;
procedure TValidationForm.btnCloseClick(Sender: TObject); begin Close; end;
procedure TValidationForm.btnSearchClick(Sender: TObject); begin RunSearch; end;

procedure TValidationForm.btnFixAllClick(Sender: TObject);
var fixed: Integer;
begin
  if not Assigned(FProject) then Exit;
  fixed := 0;
  // Auto-fix: remove broken links
  for var node in FProject.Nodes do
  begin
    if (node.NextNodeID <> '') and not Assigned(FProject.FindNode(node.NextNodeID)) then
    begin node.NextNodeID := ''; Inc(fixed); end;
    for var opt in node.PlayerOptions do
    begin
      if (opt.TargetNodeID <> '') and not Assigned(FProject.FindNode(opt.TargetNodeID)) then
      begin opt.TargetNodeID := ''; Inc(fixed); end;
      if opt.HasSkillCheck then
      begin
        if (opt.SkillCheck.SuccessNodeID <> '') and not Assigned(FProject.FindNode(opt.SkillCheck.SuccessNodeID)) then
        begin opt.SkillCheck.SuccessNodeID := ''; Inc(fixed); end;
        if (opt.SkillCheck.FailureNodeID <> '') and not Assigned(FProject.FindNode(opt.SkillCheck.FailureNodeID)) then
        begin opt.SkillCheck.FailureNodeID := ''; Inc(fixed); end;
      end;
    end;
  end;
  if fixed > 0 then
  begin
    FProject.Modified := True;
    ShowMessage('Auto-fixed ' + IntToStr(fixed) + ' broken link(s).');
    RunValidation;
  end else
    ShowMessage('No auto-fixable issues found.');
end;

procedure TValidationForm.lstIssuesDblClick(Sender: TObject);
var
  item: TListItem;
  nodeID: string;
begin
  item := lstIssues.Selected;
  if not Assigned(item) then Exit;
  if item.SubItems.Count < 2 then Exit;
  nodeID := Trim(item.SubItems[1]);
  if (nodeID <> '') and Assigned(FOnNodeSelected) then
    FOnNodeSelected(nodeID);
end;

initialization
  RegisterClass(TValidationForm);

end.

{ ============================================================ }

unit uProjectManager;

interface

uses
  System.SysUtils, System.Classes, System.IOUtils,
  Vcl.Dialogs, Vcl.Forms,
  uDialogueTypes;

type
  TRecentProject = record
    Path: string;
    Name: string;
    LastOpened: TDateTime;
  end;

  TProjectManager = class
  private
    FRecentProjects: TArray<TRecentProject>;
    FRecentFile: string;
    procedure LoadRecent;
    procedure SaveRecent;
  public
    constructor Create;
    function NewProject: TDialogueProject;
    function OpenProject(const path: string = ''): TDialogueProject;
    function SaveProject(project: TDialogueProject; saveAs: Boolean = False): Boolean;
    procedure AddToRecent(const path, name: string);
    function GetRecent: TArray<TRecentProject>;
    function CreateSampleProject: TDialogueProject;
  end;

implementation

constructor TProjectManager.Create;
begin
  inherited;
  FRecentFile := ChangeFileExt(Application.ExeName, '.recent');
  LoadRecent;
end;

procedure TProjectManager.LoadRecent;
var sl: TStringList; i: Integer;
begin
  SetLength(FRecentProjects, 0);
  if not FileExists(FRecentFile) then Exit;
  sl := TStringList.Create;
  try
    sl.LoadFromFile(FRecentFile);
    SetLength(FRecentProjects, sl.Count);
    for i := 0 to sl.Count - 1 do
    begin
      FRecentProjects[i].Path := sl.Names[i];
      FRecentProjects[i].Name := sl.ValueFromIndex[i];
      FRecentProjects[i].LastOpened := Now;
    end;
  finally sl.Free; end;
end;

procedure TProjectManager.SaveRecent;
var sl: TStringList; i: Integer;
begin
  sl := TStringList.Create;
  try
    for i := 0 to Min(High(FRecentProjects), 9) do
      sl.Add(FRecentProjects[i].Path + '=' + FRecentProjects[i].Name);
    sl.SaveToFile(FRecentFile);
  finally sl.Free; end;
end;

procedure TProjectManager.AddToRecent(const path, name: string);
var arr: TArray<TRecentProject>; i: Integer;
begin
  // Remove if already exists
  SetLength(arr, 0);
  for i := 0 to High(FRecentProjects) do
    if FRecentProjects[i].Path <> path then
    begin
      SetLength(arr, Length(arr) + 1);
      arr[High(arr)] := FRecentProjects[i];
    end;
  // Add at front
  SetLength(FRecentProjects, Length(arr) + 1);
  FRecentProjects[0].Path := path;
  FRecentProjects[0].Name := name;
  FRecentProjects[0].LastOpened := Now;
  for i := 0 to High(arr) do
    FRecentProjects[i + 1] := arr[i];
  SaveRecent;
end;

function TProjectManager.GetRecent: TArray<TRecentProject>;
begin
  Result := FRecentProjects;
end;

function TProjectManager.NewProject: TDialogueProject;
begin
  Result := TDialogueProject.Create;
  Result.Name := 'New Dialogue';
end;

function TProjectManager.OpenProject(const path: string): TDialogueProject;
var
  dlg: TOpenDialog;
  filePath: string;
  proj: TDialogueProject;
begin
  Result := nil;
  filePath := path;
  if filePath = '' then
  begin
    dlg := TOpenDialog.Create(nil);
    try
      dlg.Filter := 'Fallout Dialogue Creator|*.fdc;*.json|All Files|*.*';
      dlg.Title := 'Open Dialogue Project';
      if not dlg.Execute then Exit;
      filePath := dlg.FileName;
    finally
      dlg.Free;
    end;
  end;
  if not FileExists(filePath) then Exit;
  proj := TDialogueProject.Create;
  if proj.LoadFromFile(filePath) then
  begin
    AddToRecent(filePath, proj.Name);
    Result := proj;
  end else
  begin
    proj.Free;
    ShowMessage('Failed to load project: ' + filePath);
  end;
end;

function TProjectManager.SaveProject(project: TDialogueProject; saveAs: Boolean): Boolean;
var
  dlg: TSaveDialog;
  filePath: string;
begin
  Result := False;
  if not Assigned(project) then Exit;
  filePath := project.FilePath;
  if saveAs or (filePath = '') then
  begin
    dlg := TSaveDialog.Create(nil);
    try
      dlg.Filter := 'Fallout Dialogue Creator|*.fdc|JSON File|*.json|All Files|*.*';
      dlg.Title := 'Save Dialogue Project';
      dlg.DefaultExt := 'fdc';
      dlg.FileName := ChangeFileExt(ExtractFileName(project.Name), '');
      if not dlg.Execute then Exit;
      filePath := dlg.FileName;
    finally
      dlg.Free;
    end;
  end;
  Result := project.SaveToFile(filePath);
  if Result then
    AddToRecent(filePath, project.Name);
end;

function TProjectManager.CreateSampleProject: TDialogueProject;
var
  proj: TDialogueProject;
  node1, node2, node3, node4, node5, node6: TDialogueNode;
  opt1, opt2, opt3: TPlayerOption;
begin
  proj := TDialogueProject.Create;
  proj.Name := 'Sample Dialogue - Harold the Ghoul';
  proj.NPCName := 'Harold';
  proj.NPCScript := 'harold_dialogue';
  proj.Description := 'A sample branching dialogue tree demonstrating FDC features.';
  proj.Author := 'Fallout Dialogue Creator';
  proj.Version := '1.0';

  // Initial greeting node
  node1 := proj.AddNode(ntNPCDialogue);
  node1.Speaker := 'Harold';
  node1.Text := 'Oh, another wanderer passing through the wasteland. Guess you''re not here to trade, or you would''ve said so by now. What do you want?';
  node1.X := 60; node1.Y := 80;
  node1.Width := 280; node1.Height := 120;
  node1.IsStartNode := True;
  proj.StartNodeID := node1.ID;

  // Player reply node
  node2 := proj.AddNode(ntPlayerReply);
  node2.Speaker := 'Player';
  node2.X := 420; node2.Y := 80;
  node2.Width := 280; node2.Height := 160;
  node1.NextNodeID := node2.ID;

  opt1 := TPlayerOption.Create;
  opt1.Text := 'I''m looking for information about the vault.';
  opt1.TargetNodeID := '';  // Will be set below
  node2.PlayerOptions.Add(opt1);

  opt2 := TPlayerOption.Create;
  opt2.Text := '[Speech 60%] Maybe we can help each other out. I have caps.';
  opt2.HasSkillCheck := True;
  opt2.SkillCheck.Skill := skSpeech;
  opt2.SkillCheck.Difficulty := 60;
  opt2.SkillCheck.XPReward := 50;
  opt2.SkillCheck.SuccessMessage := 'Your silver tongue works its magic.';
  opt2.SkillCheck.FailureMessage := 'Harold sees right through you.';
  node2.PlayerOptions.Add(opt2);

  opt3 := TPlayerOption.Create;
  opt3.Text := 'Never mind. Goodbye.';
  node2.PlayerOptions.Add(opt3);

  // Vault info response
  node3 := proj.AddNode(ntNPCDialogue);
  node3.Speaker := 'Harold';
  node3.Text := 'The vault? Heh, you and half the wasteland. Word is there''s an old Vault-Tec facility east of here, past the rad scorpion territory. Can''t miss it — look for the mountain with the big crack in it.';
  node3.X := 780; node3.Y := 40;
  node3.Width := 280; node3.Height := 140;
  opt1.TargetNodeID := node3.ID;

  // Speech success node
  node4 := proj.AddNode(ntNPCDialogue);
  node4.Speaker := 'Harold';
  node4.Text := 'Ha! Now you''re talking my language. Alright, I''ll tell you what I know — and believe me, Harold knows plenty. Pull up a rock and sit down.';
  node4.X := 780; node4.Y := 200;
  node4.Width := 280; node4.Height := 120;
  opt2.SkillCheck.SuccessNodeID := node4.ID;

  // Speech fail node
  node5 := proj.AddNode(ntNPCDialogue);
  node5.Speaker := 'Harold';
  node5.Text := 'Caps? You think Harold can be bought that easy? I''ve been around since before you were a twinkle in your daddy''s eye. Go peddle that somewhere else.';
  node5.X := 780; node5.Y := 360;
  node5.Width := 280; node5.Height := 120;
  opt2.SkillCheck.FailureNodeID := node5.ID;

  // Quest update node after vault info
  node6 := proj.AddNode(ntQuestUpdate);
  node6.QuestID := 'FIND_THE_VAULT';
  node6.QuestFlag := '1';
  node6.X := 1120; node6.Y := 40;
  node6.Width := 200; node6.Height := 80;
  node3.NextNodeID := node6.ID;

  // End node
  var nodeEnd := proj.AddNode(ntEndDialogue);
  nodeEnd.X := 1120; nodeEnd.Y := 200;
  nodeEnd.Width := 160; nodeEnd.Height := 60;
  node6.NextNodeID := nodeEnd.ID;
  node5.NextNodeID := nodeEnd.ID;

  // Float messages
  var float1 := TFloatMessage.Create;
  float1.Text := 'Damned rad scorpions...';
  float1.Category := 'Ambient';
  float1.Priority := 5;
  float1.Weight := 3;
  float1.IsAmbient := True;
  proj.FloatMessages.Add(float1);

  var float2 := TFloatMessage.Create;
  float2.Text := 'I''ve seen things that would make your hair fall out. Not that mine didn''t already.';
  float2.Category := 'Ambient';
  float2.Priority := 6;
  float2.Weight := 2;
  float2.IsAmbient := True;
  proj.FloatMessages.Add(float2);

  var float3 := TFloatMessage.Create;
  float3.Text := 'Don''t make me call Bob!';
  float3.Category := 'Combat Taunt';
  float3.Priority := 8;
  float3.Weight := 1;
  float3.IsCombatTaunt := True;
  proj.FloatMessages.Add(float3);

  // Global vars
  proj.GlobalVars.Add('GVAR_MET_HAROLD', '0');
  proj.GlobalVars.Add('GVAR_VAULT_LOCATION_KNOWN', '0');

  proj.Modified := False;
  Result := proj;
end;

end.

{ ============================================================ }

unit uSearchPanel;

interface
// Search panel is integrated into the main form as a dockable sidebar
// This unit provides search helper functions

uses System.SysUtils, System.Classes, uDialogueTypes;

type
  TSearchResult = record
    NodeID: string;
    Field: string;
    Context: string;
  end;

  TSearchHelper = class
    class function SearchProject(project: TDialogueProject; const query: string;
      caseSensitive: Boolean = False): TArray<TSearchResult>;
  end;

implementation

class function TSearchHelper.SearchProject(project: TDialogueProject;
  const query: string; caseSensitive: Boolean): TArray<TSearchResult>;
var
  results: TArray<TSearchResult>;
  node: TDialogueNode;
  q: string;

  procedure AddResult(const nodeID, field, ctx: string);
  begin
    SetLength(results, Length(results) + 1);
    results[High(results)].NodeID := nodeID;
    results[High(results)].Field := field;
    results[High(results)].Context := ctx;
  end;

  function Match(const s: string): Boolean;
  begin
    if caseSensitive then Result := Pos(q, s) > 0
    else Result := Pos(LowerCase(q), LowerCase(s)) > 0;
  end;

begin
  q := query;
  SetLength(results, 0);
  if not Assigned(project) or (Trim(q) = '') then begin Result := results; Exit; end;

  for node in project.Nodes do
  begin
    if Match(node.Text) then AddResult(node.ID, 'Text', Copy(node.Text, 1, 80));
    if Match(node.Speaker) then AddResult(node.ID, 'Speaker', node.Speaker);
    if Match(node.Tag) then AddResult(node.ID, 'Tag', node.Tag);
    if Match(node.QuestID) then AddResult(node.ID, 'QuestID', node.QuestID);
    if Match(node.Notes) then AddResult(node.ID, 'Notes', Copy(node.Notes, 1, 80));
    for var opt in node.PlayerOptions do
    begin
      if Match(opt.Text) then AddResult(node.ID, 'Option', Copy(opt.Text, 1, 80));
      if Match(opt.ItemRequired) then AddResult(node.ID, 'ItemReq', opt.ItemRequired);
    end;
    for var sc in node.Scripts do
      if Match(sc.ScriptCode) then AddResult(node.ID, 'Script', Copy(sc.ScriptCode, 1, 80));
  end;

  for var msg in project.FloatMessages do
    if Match(msg.Text) then AddResult('FLOAT:' + msg.ID, 'FloatMsg', Copy(msg.Text, 1, 80));

  Result := results;
end;

end.
