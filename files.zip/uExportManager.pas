unit uExportManager;

interface

uses
  System.SysUtils, System.Classes, System.Generics.Collections,
  System.JSON, System.IOUtils,
  uDialogueTypes;

type
  TExportFormat = (efJSON, efMSG, efSSL, efLocalization, efPackage);

  TExportOptions = record
    Format: TExportFormat;
    OutputPath: string;
    IncludeComments: Boolean;
    IncludeMetadata: Boolean;
    MinifyJSON: Boolean;
    SplitFiles: Boolean;
    Encoding: string;   // 'UTF-8', 'ASCII', 'WIN1252'
    LineEnding: string; // 'CRLF', 'LF'
    MsgFilePrefix: string;
    SSLClassName: string;
    IncludeFloatMessages: Boolean;
    LocaleFilter: string;
  end;

  TExportResult = record
    Success: Boolean;
    FilesGenerated: TArray<string>;
    Warnings: TArray<string>;
    Errors: TArray<string>;
    NodeCount: Integer;
    LineCount: Integer;
  end;

  TExportManager = class
  private
    FProject: TDialogueProject;
    FLog: TStringList;

    function ExportToJSON(const opts: TExportOptions): TExportResult;
    function ExportToMSG(const opts: TExportOptions): TExportResult;
    function ExportToSSL(const opts: TExportOptions): TExportResult;
    function ExportToLocalization(const opts: TExportOptions): TExportResult;
    function ExportPackage(const opts: TExportOptions): TExportResult;

    function GenerateMSGContent: TStringList;
    function GenerateSSLContent: TStringList;
    function GenerateSSLNode(node: TDialogueNode; indent: Integer): string;
    function GenerateConditionSSL(const cond: TCondition): string;
    function GenerateSkillCheckSSL(const sk: TSkillCheck; const optID: string): string;

    procedure AddLog(const msg: string);
    procedure AddWarning(var result: TExportResult; const msg: string);
    procedure AddError(var result: TExportResult; const msg: string);

    function EnsureDir(const path: string): Boolean;
    function SafeWriteFile(const path, content: string; const encoding: string): Boolean;
    function IndentStr(level: Integer): string;
    function EscapeMSGText(const s: string): string;
    function NodeToMSGComment(node: TDialogueNode): string;
  public
    constructor Create(project: TDialogueProject);
    destructor Destroy; override;

    function Export(const opts: TExportOptions): TExportResult;
    function ValidateBeforeExport: TStringList;

    class function DefaultOptions: TExportOptions;
    class function FormatName(fmt: TExportFormat): string;

    property Log: TStringList read FLog;
  end;

implementation

uses
  System.StrUtils, System.DateUtils;

const
  SSL_HEADER =
    '/* ============================================================' + sLineBreak +
    ' * Fallout Dialogue Creator - Auto-generated SSL Script' + sLineBreak +
    ' * DO NOT EDIT MANUALLY - regenerate from FDC project file' + sLineBreak +
    ' * ============================================================ */' + sLineBreak;

  MSG_HEADER =
    '# Fallout Dialogue Creator - Auto-generated Message File' + sLineBreak +
    '# Format: {line_number}{nul}{sound_file}{nul}{text}' + sLineBreak;

{ TExportManager }

constructor TExportManager.Create(project: TDialogueProject);
begin
  inherited Create;
  FProject := project;
  FLog := TStringList.Create;
end;

destructor TExportManager.Destroy;
begin
  FLog.Free;
  inherited;
end;

class function TExportManager.DefaultOptions: TExportOptions;
begin
  Result.Format := efJSON;
  Result.OutputPath := '';
  Result.IncludeComments := True;
  Result.IncludeMetadata := True;
  Result.MinifyJSON := False;
  Result.SplitFiles := False;
  Result.Encoding := 'UTF-8';
  Result.LineEnding := 'CRLF';
  Result.MsgFilePrefix := 'dialog_';
  Result.SSLClassName := '';
  Result.IncludeFloatMessages := True;
  Result.LocaleFilter := '';
end;

class function TExportManager.FormatName(fmt: TExportFormat): string;
begin
  case fmt of
    efJSON:         Result := 'Dialogue JSON';
    efMSG:          Result := 'Fallout .MSG File';
    efSSL:          Result := 'Fallout .SSL Script';
    efLocalization: Result := 'Localization Pack';
    efPackage:      Result := 'Engine Package';
  end;
end;

procedure TExportManager.AddLog(const msg: string);
begin
  FLog.Add(FormatDateTime('hh:nn:ss', Now) + '  ' + msg);
end;

procedure TExportManager.AddWarning(var result: TExportResult; const msg: string);
begin
  var arr := result.Warnings;
  SetLength(arr, Length(arr) + 1);
  arr[High(arr)] := msg;
  result.Warnings := arr;
  AddLog('WARNING: ' + msg);
end;

procedure TExportManager.AddError(var result: TExportResult; const msg: string);
begin
  var arr := result.Errors;
  SetLength(arr, Length(arr) + 1);
  arr[High(arr)] := msg;
  result.Errors := arr;
  AddLog('ERROR: ' + msg);
end;

function TExportManager.EnsureDir(const path: string): Boolean;
begin
  Result := True;
  try
    if not TDirectory.Exists(path) then
      TDirectory.CreateDirectory(path);
  except
    Result := False;
  end;
end;

function TExportManager.IndentStr(level: Integer): string;
begin
  Result := StringOfChar(' ', level * 2);
end;

function TExportManager.EscapeMSGText(const s: string): string;
begin
  Result := StringReplace(s, '{', '[', [rfReplaceAll]);
  Result := StringReplace(Result, '}', ']', [rfReplaceAll]);
  Result := StringReplace(Result, #13#10, ' ', [rfReplaceAll]);
  Result := StringReplace(Result, #10, ' ', [rfReplaceAll]);
end;

function TExportManager.NodeToMSGComment(node: TDialogueNode): string;
begin
  Result := '# [' + NODE_TYPE_NAMES[node.NodeType] + ']';
  if node.Speaker <> '' then Result := Result + ' ' + node.Speaker;
  Result := Result + ' ID:' + Copy(node.ID, 1, 12);
end;

function TExportManager.SafeWriteFile(const path, content: string; const encoding: string): Boolean;
var
  sl: TStringList;
  enc: TEncoding;
begin
  Result := False;
  sl := TStringList.Create;
  try
    sl.Text := content;
    if SameText(encoding, 'ASCII') then
      enc := TEncoding.ASCII
    else if SameText(encoding, 'WIN1252') then
      enc := TEncoding.GetEncoding(1252)
    else
      enc := TEncoding.UTF8;
    try
      sl.SaveToFile(path, enc);
      Result := True;
    except on E: Exception do
      AddLog('File write failed: ' + path + ' - ' + E.Message);
    end;
  finally
    sl.Free;
  end;
end;

function TExportManager.ValidateBeforeExport: TStringList;
begin
  Result := FProject.ValidateProject;
end;

function TExportManager.Export(const opts: TExportOptions): TExportResult;
begin
  FLog.Clear;
  AddLog('Export started: ' + FormatName(opts.Format));
  AddLog('Project: ' + FProject.Name);
  AddLog('Nodes: ' + IntToStr(FProject.Nodes.Count));

  case opts.Format of
    efJSON:         Result := ExportToJSON(opts);
    efMSG:          Result := ExportToMSG(opts);
    efSSL:          Result := ExportToSSL(opts);
    efLocalization: Result := ExportToLocalization(opts);
    efPackage:      Result := ExportPackage(opts);
  end;

  if Result.Success then
    AddLog('Export complete. Files: ' + IntToStr(Length(Result.FilesGenerated)))
  else
    AddLog('Export FAILED with ' + IntToStr(Length(Result.Errors)) + ' error(s).');
end;

{ JSON Export }
function TExportManager.ExportToJSON(const opts: TExportOptions): TExportResult;
var
  jsonObj: TJSONObject;
  content: string;
  outPath: string;
begin
  Result.Success := False;
  Result.NodeCount := FProject.Nodes.Count;

  if not EnsureDir(ExtractFilePath(opts.OutputPath)) then
  begin
    AddError(Result, 'Cannot create output directory: ' + ExtractFilePath(opts.OutputPath));
    Exit;
  end;

  outPath := opts.OutputPath;
  if ExtractFileExt(outPath) = '' then
    outPath := outPath + '.json';

  jsonObj := FProject.ToJSON;
  try
    if opts.MinifyJSON then
      content := jsonObj.ToString
    else
      content := jsonObj.Format(2);
  finally
    jsonObj.Free;
  end;

  if opts.IncludeComments then
  begin
    content := '// Fallout Dialogue Creator Project Export' + sLineBreak +
               '// Generated: ' + DateTimeToStr(Now) + sLineBreak +
               '// Nodes: ' + IntToStr(FProject.Nodes.Count) + sLineBreak +
               content;
  end;

  if SafeWriteFile(outPath, content, opts.Encoding) then
  begin
    Result.Success := True;
    Result.FilesGenerated := [outPath];
    Result.LineCount := FProject.Nodes.Count;
    AddLog('JSON written: ' + outPath);
  end else
    AddError(Result, 'Failed to write: ' + outPath);
end;

{ MSG Export }
function TExportManager.GenerateMSGContent: TStringList;
var
  node: TDialogueNode;
  opt: TPlayerOption;
  lineNum: Integer;
  npcName: string;
begin
  Result := TStringList.Create;
  Result.Add(MSG_HEADER);
  Result.Add('');

  npcName := FProject.NPCName;
  if npcName = '' then npcName := 'NPC';

  lineNum := 100;
  for node in FProject.Nodes do
  begin
    if node.NodeType = ntComment then Continue;

    Result.Add(NodeToMSGComment(node));

    // NPC text
    if Trim(node.Text) <> '' then
    begin
      var voiceRef := '';
      if node.VoiceFile <> '' then
        voiceRef := ChangeFileExt(ExtractFileName(node.VoiceFile), '');
      Result.Add(Format('{%d}{%s}{%s}', [lineNum, voiceRef,
        EscapeMSGText(node.Text)]));
      Inc(lineNum, 10);
    end;

    // Player options
    for opt in node.PlayerOptions do
    begin
      if Trim(opt.Text) <> '' then
      begin
        var optComment := '# Option';
        if opt.HasSkillCheck then
          optComment := optComment + ' [SKILL:' + SKILL_NAMES[opt.SkillCheck.Skill] + ']';
        if opt.IsHidden then
          optComment := optComment + ' [HIDDEN]';
        Result.Add(optComment);
        Result.Add(Format('{%d}{}{%s}', [lineNum, EscapeMSGText(opt.Text)]));
        Inc(lineNum, 10);

        if opt.HasSkillCheck then
        begin
          if opt.SkillCheck.SuccessMessage <> '' then
          begin
            Result.Add('# Skill check success');
            Result.Add(Format('{%d}{}{%s}', [lineNum,
              EscapeMSGText(opt.SkillCheck.SuccessMessage)]));
            Inc(lineNum, 10);
          end;
          if opt.SkillCheck.FailureMessage <> '' then
          begin
            Result.Add('# Skill check failure');
            Result.Add(Format('{%d}{}{%s}', [lineNum,
              EscapeMSGText(opt.SkillCheck.FailureMessage)]));
            Inc(lineNum, 10);
          end;
        end;
      end;
    end;
    Result.Add('');
    Inc(lineNum, 10);
  end;

  // Float messages
  if FProject.FloatMessages.Count > 0 then
  begin
    Result.Add('# ====== Float Messages ======');
    for var msg in FProject.FloatMessages do
    begin
      if Trim(msg.Text) = '' then Continue;
      Result.Add('# [' + msg.Category + '] Priority:' + IntToStr(msg.Priority) +
        ' Weight:' + IntToStr(msg.Weight));
      Result.Add(Format('{%d}{}{%s}', [lineNum, EscapeMSGText(msg.Text)]));
      Inc(lineNum, 10);
    end;
  end;
end;

function TExportManager.ExportToMSG(const opts: TExportOptions): TExportResult;
var
  content: TStringList;
  outPath: string;
begin
  Result.Success := False;
  Result.NodeCount := FProject.Nodes.Count;

  if not EnsureDir(ExtractFilePath(opts.OutputPath)) then
  begin
    AddError(Result, 'Cannot create output directory');
    Exit;
  end;

  outPath := opts.OutputPath;
  if ExtractFileExt(outPath) = '' then
    outPath := outPath + '.msg';

  content := GenerateMSGContent;
  try
    Result.LineCount := content.Count;
    if SafeWriteFile(outPath, content.Text, opts.Encoding) then
    begin
      Result.Success := True;
      Result.FilesGenerated := [outPath];
      AddLog('MSG written: ' + outPath + ' (' + IntToStr(content.Count) + ' lines)');
    end else
      AddError(Result, 'Failed to write MSG: ' + outPath);
  finally
    content.Free;
  end;
end;

{ SSL Script Export }
function TExportManager.GenerateConditionSSL(const cond: TCondition): string;
var
  varRef, op: string;
begin
  op := OPERATOR_NAMES[cond.Operator];
  case cond.CondType of
    ctSkillCheck:   varRef := 'has_skill(dude, SKILL_' + UpperCase(StringReplace(cond.Variable, ' ', '_', [rfReplaceAll])) + ', ' + cond.Value + ')';
    ctStatCheck:    varRef := 'stat_level(dude, STAT_' + UpperCase(cond.Variable) + ') ' + op + ' ' + cond.Value;
    ctReputation:   varRef := 'reputation_level(dude) ' + op + ' ' + cond.Value;
    ctKarma:        varRef := 'karma_points(dude) ' + op + ' ' + cond.Value;
    ctGlobalVar:    varRef := 'global_var(GVAR_' + UpperCase(cond.Variable) + ') ' + op + ' ' + cond.Value;
    ctLocalVar:     varRef := 'local_var(LVAR_' + UpperCase(cond.Variable) + ') ' + op + ' ' + cond.Value;
    ctQuestFlag:    varRef := 'quest_state(' + cond.Variable + ') ' + op + ' ' + cond.Value;
    ctInventory:    varRef := 'obj_is_carrying_obj_pid(dude, PID_' + UpperCase(cond.Variable) + ') ' + op + ' ' + cond.Value;
    ctCompanion:    varRef := 'party_member_obj(PID_' + UpperCase(cond.Variable) + ') != 0';
    ctRandom:       varRef := 'random(0, 100) < ' + cond.Value;
  else
    varRef := '(* unsupported condition type *)';
  end;
  Result := varRef;
end;

function TExportManager.GenerateSkillCheckSSL(const sk: TSkillCheck; const optID: string): string;
var
  skillConst: string;
begin
  skillConst := 'SKILL_' + UpperCase(StringReplace(SKILL_NAMES[sk.Skill], ' ', '_', [rfReplaceAll]));
  Result :=
    '    (* Skill check: ' + SKILL_NAMES[sk.Skill] + ' vs ' + IntToStr(sk.Difficulty) + ' *)' + sLineBreak +
    '    if (has_skill(dude, ' + skillConst + ', ' + IntToStr(sk.Difficulty) + ')) then begin' + sLineBreak;
  if sk.XPReward > 0 then
    Result := Result + '      give_exp_points(' + IntToStr(sk.XPReward) + ');' + sLineBreak;
  if sk.SuccessNodeID <> '' then
    Result := Result + '      (* Success → node: ' + Copy(sk.SuccessNodeID, 1, 12) + ' *)' + sLineBreak +
      '      goto_node_' + SafeStr(sk.SuccessNodeID) + ';' + sLineBreak;
  Result := Result + '    end else begin' + sLineBreak;
  if sk.FailureNodeID <> '' then
    Result := Result + '      (* Failure → node: ' + Copy(sk.FailureNodeID, 1, 12) + ' *)' + sLineBreak +
      '      goto_node_' + SafeStr(sk.FailureNodeID) + ';' + sLineBreak;
  Result := Result + '    end;' + sLineBreak;
end;

function TExportManager.GenerateSSLNode(node: TDialogueNode; indent: Integer): string;
var
  s: string;
  ind: string;
  opt: TPlayerOption;
  cond: TCondition;
  i: Integer;
  first: Boolean;
begin
  ind := IndentStr(indent);
  s := '';

  s := s + ind + '(* NODE: ' + NODE_TYPE_NAMES[node.NodeType];
  if node.Speaker <> '' then s := s + '  Speaker: ' + node.Speaker;
  s := s + ' *)' + sLineBreak;
  s := s + ind + 'node_' + SafeStr(node.ID) + ':' + sLineBreak;
  s := s + ind + 'begin' + sLineBreak;

  // Conditions
  if node.Conditions.Count > 0 then
  begin
    s := s + ind + '  (* Entry conditions *)' + sLineBreak;
    s := s + ind + '  if not (';
    first := True;
    for cond in node.Conditions do
    begin
      if not first then
      begin
        case cond.BoolOp of
          boAND: s := s + ' and ';
          boOR:  s := s + ' or ';
          boNOT: s := s + ' and not ';
        end;
      end;
      s := s + GenerateConditionSSL(cond);
      first := False;
    end;
    s := s + ') then' + sLineBreak;
    s := s + ind + '    return;' + sLineBreak;
    s := s + ind + '  end;' + sLineBreak;
  end;

  case node.NodeType of
    ntNPCDialogue:
    begin
      s := s + ind + '  (* NPC speaks *)' + sLineBreak;
      if Trim(node.Text) <> '' then
        s := s + ind + '  (* "' + Copy(EscapeMSGText(node.Text), 1, 60) + '" *)' + sLineBreak;
      s := s + ind + '  Reply(node_' + SafeStr(node.ID) + '_text_id);' + sLineBreak;
    end;
    ntPlayerReply:
    begin
      s := s + ind + '  (* Player dialogue options *)' + sLineBreak;
      for i := 0 to node.PlayerOptions.Count - 1 do
      begin
        opt := node.PlayerOptions[i];
        s := s + ind + '  Option(' + IntToStr(i) + ', node_' + SafeStr(node.ID) + '_opt' + IntToStr(i) + '_text_id';
        if opt.IsHidden then s := s + ', OPTION_HIDDEN';
        s := s + ');' + sLineBreak;
      end;
    end;
    ntConditional:
    begin
      s := s + ind + '  (* Conditional branch *)' + sLineBreak;
      if node.Conditions.Count > 0 then
      begin
        s := s + ind + '  if (';
        first := True;
        for cond in node.Conditions do
        begin
          if not first then s := s + ' and ';
          s := s + GenerateConditionSSL(cond);
          first := False;
        end;
        s := s + ') then' + sLineBreak;
        if node.NextNodeID <> '' then
          s := s + ind + '    goto node_' + SafeStr(node.NextNodeID) + ';' + sLineBreak;
        s := s + ind + '  end;' + sLineBreak;
      end;
    end;
    ntScript:
    begin
      s := s + ind + '  (* Script execution *)' + sLineBreak;
      for var sc in node.Scripts do
        if sc.IsEnabled and (Trim(sc.ScriptCode) <> '') then
        begin
          s := s + ind + '  (* Event: ' + GetEnumName(TypeInfo(TScriptEvent), Ord(sc.EventType)) + ' *)' + sLineBreak;
          // Add the script code lines indented
          var codeLines := sc.ScriptCode.Split([sLineBreak]);
          for var line in codeLines do
            s := s + ind + '  ' + line + sLineBreak;
        end;
    end;
    ntCombatTrigger:
    begin
      s := s + ind + '  (* Combat trigger *)' + sLineBreak;
      if node.CombatScript <> '' then
        s := s + ind + '  ' + node.CombatScript + sLineBreak
      else
        s := s + ind + '  attack_complex(self, 8, 0, -1, -1, 0, 0);' + sLineBreak;
    end;
    ntQuestUpdate:
    begin
      s := s + ind + '  (* Quest update *)' + sLineBreak;
      if node.QuestID <> '' then
        s := s + ind + '  set_quest_state(QUEST_' + UpperCase(node.QuestID) + ', ' +
          IfThen(node.QuestFlag <> '', node.QuestFlag, '1') + ');' + sLineBreak;
    end;
    ntTrade:
    begin
      s := s + ind + '  (* Trade screen *)' + sLineBreak;
      s := s + ind + '  start_gdialog(self, BARTER_SCRIPT, BARTER_BARTER, -1, -1);' + sLineBreak;
    end;
    ntEndDialogue:
    begin
      s := s + ind + '  (* End dialogue *)' + sLineBreak;
      s := s + ind + '  gDone := TRUE;' + sLineBreak;
    end;
    ntRandom:
    begin
      s := s + ind + '  (* Random branch: weight=' + IntToStr(node.RandomWeight) + ' *)' + sLineBreak;
    end;
  end;

  // Player options with skill checks
  for i := 0 to node.PlayerOptions.Count - 1 do
  begin
    opt := node.PlayerOptions[i];
    if opt.HasSkillCheck then
    begin
      s := s + ind + '  (* Option ' + IntToStr(i) + ' skill check *)' + sLineBreak;
      s := s + GenerateSkillCheckSSL(opt.SkillCheck, opt.ID);
    end else if opt.TargetNodeID <> '' then
    begin
      s := s + ind + '  (* Option ' + IntToStr(i) + ' → node *)' + sLineBreak;
    end;
  end;

  // Default next node
  if (node.NextNodeID <> '') and (node.NodeType <> ntEndDialogue) then
    s := s + ind + '  goto node_' + SafeStr(node.NextNodeID) + ';' + sLineBreak;

  s := s + ind + 'end;' + sLineBreak;
  s := s + sLineBreak;
  Result := s;
end;

function TExportManager.GenerateSSLContent: TStringList;
var
  node: TDialogueNode;
  className: string;
begin
  Result := TStringList.Create;
  className := FProject.NPCScript;
  if className = '' then
    className := StringReplace(FProject.NPCName, ' ', '_', [rfReplaceAll]);
  if className = '' then className := 'npc_dialogue';

  Result.Add(SSL_HEADER);
  Result.Add('');
  Result.Add('/* Project: ' + FProject.Name + ' */');
  Result.Add('/* NPC: ' + FProject.NPCName + ' */');
  Result.Add('/* Generated: ' + DateTimeToStr(Now) + ' */');
  Result.Add('/* Nodes: ' + IntToStr(FProject.Nodes.Count) + ' */');
  Result.Add('');
  Result.Add('#include "HEADERS\DEFINE.H"');
  Result.Add('#include "HEADERS\DIALOG.H"');
  Result.Add('');
  Result.Add('procedure start;');
  Result.Add('procedure talk;');
  Result.Add('procedure combat;');
  Result.Add('procedure critter_p_proc;');
  Result.Add('');
  Result.Add('(* Global variables *)');
  for var pair in FProject.GlobalVars do
    Result.Add('variable LVAR_' + UpperCase(pair.Key) + ' := 0;');
  Result.Add('');
  Result.Add('procedure start begin');
  Result.Add('  (* Script initialization *)');
  Result.Add('end');
  Result.Add('');
  Result.Add('procedure talk begin');
  Result.Add('  if (dialogue_reaction(dude_reaction_to_me) > 25) then begin');
  if FProject.StartNodeID <> '' then
    Result.Add('    goto node_' + SafeStr(FProject.StartNodeID) + ';')
  else if FProject.Nodes.Count > 0 then
    Result.Add('    goto node_' + SafeStr(FProject.Nodes[0].ID) + ';');
  Result.Add('  end;');
  Result.Add('end');
  Result.Add('');

  // Generate node procedures
  for node in FProject.Nodes do
  begin
    if node.NodeType = ntComment then Continue;
    Result.Add(GenerateSSLNode(node, 0));
  end;

  Result.Add('procedure combat begin');
  Result.Add('  (* Combat handler *)');
  Result.Add('  if (dude_is_target) then begin');
  Result.Add('    attack_complex(self, 8, 0, -1, -1, 0, 0);');
  Result.Add('  end;');
  Result.Add('end');
  Result.Add('');
  Result.Add('procedure critter_p_proc begin');
  Result.Add('end');
end;

function TExportManager.ExportToSSL(const opts: TExportOptions): TExportResult;
var
  content: TStringList;
  outPath: string;
begin
  Result.Success := False;
  Result.NodeCount := FProject.Nodes.Count;

  if not EnsureDir(ExtractFilePath(opts.OutputPath)) then
  begin
    AddError(Result, 'Cannot create output directory');
    Exit;
  end;

  outPath := opts.OutputPath;
  if ExtractFileExt(outPath) = '' then
    outPath := outPath + '.ssl';

  content := GenerateSSLContent;
  try
    Result.LineCount := content.Count;
    if SafeWriteFile(outPath, content.Text, opts.Encoding) then
    begin
      Result.Success := True;
      Result.FilesGenerated := [outPath];
      AddLog('SSL written: ' + outPath + ' (' + IntToStr(content.Count) + ' lines)');
      if Result.NodeCount > 50 then
        AddWarning(Result, 'Large dialogue tree (' + IntToStr(Result.NodeCount) +
          ' nodes). Review SSL file for goto depth limits.');
    end else
      AddError(Result, 'Failed to write SSL: ' + outPath);
  finally
    content.Free;
  end;
end;

{ Localization Export }
function TExportManager.ExportToLocalization(const opts: TExportOptions): TExportResult;
var
  jsonRoot, langObj: TJSONObject;
  stringsArr: TJSONArray;
  node: TDialogueNode;
  opt: TPlayerOption;
  msg: TFloatMessage;
  outPath: string;
  locale: string;
begin
  Result.Success := False;
  Result.NodeCount := FProject.Nodes.Count;

  if not EnsureDir(ExtractFilePath(opts.OutputPath)) then
  begin
    AddError(Result, 'Cannot create output directory');
    Exit;
  end;

  locale := opts.LocaleFilter;
  if locale = '' then locale := FProject.ActiveLocale;
  if locale = '' then locale := 'en-US';

  outPath := opts.OutputPath;
  if ExtractFileExt(outPath) = '' then
    outPath := outPath + '_' + locale + '.json';

  jsonRoot := TJSONObject.Create;
  try
    jsonRoot.AddPair('locale', locale);
    jsonRoot.AddPair('project', FProject.Name);
    jsonRoot.AddPair('generated', DateTimeToStr(Now));

    stringsArr := TJSONArray.Create;

    for node in FProject.Nodes do
    begin
      if node.NodeType = ntComment then Continue;
      if Trim(node.Text) = '' then Continue;

      var entry := TJSONObject.Create;
      entry.AddPair('key', 'node_' + node.ID + '_text');
      entry.AddPair('context', NODE_TYPE_NAMES[node.NodeType] +
        IfThen(node.Speaker <> '', ' (' + node.Speaker + ')', ''));
      entry.AddPair('source', node.Text);
      entry.AddPair('translation', node.Text); // Placeholder
      stringsArr.Add(entry);

      for var i := 0 to node.PlayerOptions.Count - 1 do
      begin
        opt := node.PlayerOptions[i];
        if Trim(opt.Text) = '' then Continue;
        var optEntry := TJSONObject.Create;
        optEntry.AddPair('key', 'node_' + node.ID + '_opt' + IntToStr(i));
        optEntry.AddPair('context', 'Player option ' + IntToStr(i));
        optEntry.AddPair('source', opt.Text);
        optEntry.AddPair('translation', opt.Text);
        stringsArr.Add(optEntry);
      end;
    end;

    if opts.IncludeFloatMessages then
      for msg in FProject.FloatMessages do
      begin
        if Trim(msg.Text) = '' then Continue;
        var msgEntry := TJSONObject.Create;
        msgEntry.AddPair('key', 'float_' + msg.ID);
        msgEntry.AddPair('context', 'Float message [' + msg.Category + ']');
        msgEntry.AddPair('source', msg.Text);
        msgEntry.AddPair('translation', msg.Text);
        stringsArr.Add(msgEntry);
      end;

    jsonRoot.AddPair('strings', stringsArr);
    jsonRoot.AddPair('count', TJSONNumber.Create(stringsArr.Count));

    var content := jsonRoot.Format(2);
    if SafeWriteFile(outPath, content, opts.Encoding) then
    begin
      Result.Success := True;
      Result.FilesGenerated := [outPath];
      Result.LineCount := stringsArr.Count;
      AddLog('Localization pack written: ' + outPath + ' (' + IntToStr(stringsArr.Count) + ' strings)');
    end else
      AddError(Result, 'Failed to write localization: ' + outPath);
  finally
    jsonRoot.Free;
  end;
end;

{ Package Export - bundles all formats }
function TExportManager.ExportPackage(const opts: TExportOptions): TExportResult;
var
  baseDir: string;
  subOpts: TExportOptions;
  subResult: TExportResult;
  allFiles: TStringList;
  manifestObj: TJSONObject;
  manifestPath: string;
begin
  Result.Success := False;
  Result.NodeCount := FProject.Nodes.Count;
  allFiles := TStringList.Create;
  try
    baseDir := IncludeTrailingPathDelimiter(opts.OutputPath);
    if not EnsureDir(baseDir) then
    begin
      AddError(Result, 'Cannot create package directory: ' + baseDir);
      Exit;
    end;

    var npcName := FProject.NPCName;
    if npcName = '' then npcName := 'dialogue';
    npcName := StringReplace(LowerCase(npcName), ' ', '_', [rfReplaceAll]);

    AddLog('Generating engine package in: ' + baseDir);

    // JSON project
    subOpts := opts;
    subOpts.Format := efJSON;
    subOpts.OutputPath := baseDir + npcName + '.json';
    subResult := Export(subOpts);
    if subResult.Success then
      allFiles.Add(subOpts.OutputPath)
    else
      for var e in subResult.Errors do AddError(Result, 'JSON: ' + e);

    // MSG file
    subOpts.Format := efMSG;
    subOpts.OutputPath := baseDir + npcName + '.msg';
    subResult := Export(subOpts);
    if subResult.Success then
      allFiles.Add(subOpts.OutputPath)
    else
      for var e in subResult.Errors do AddError(Result, 'MSG: ' + e);

    // SSL script
    subOpts.Format := efSSL;
    subOpts.OutputPath := baseDir + npcName + '.ssl';
    subResult := Export(subOpts);
    if subResult.Success then
      allFiles.Add(subOpts.OutputPath)
    else
      for var e in subResult.Errors do AddError(Result, 'SSL: ' + e);

    // Localization
    for var locale in FProject.Locales do
    begin
      subOpts.Format := efLocalization;
      subOpts.OutputPath := baseDir + 'loc\' + npcName + '_' + locale + '.json';
      subOpts.LocaleFilter := locale;
      if EnsureDir(baseDir + 'loc\') then
      begin
        subResult := Export(subOpts);
        if subResult.Success then
          allFiles.Add(subOpts.OutputPath);
      end;
    end;

    // Write package manifest
    manifestObj := TJSONObject.Create;
    try
      manifestObj.AddPair('package', FProject.Name);
      manifestObj.AddPair('npc', FProject.NPCName);
      manifestObj.AddPair('version', FProject.Version);
      manifestObj.AddPair('author', FProject.Author);
      manifestObj.AddPair('generated', DateTimeToStr(Now));
      manifestObj.AddPair('nodeCount', TJSONNumber.Create(FProject.Nodes.Count));
      manifestObj.AddPair('fdc_version', '1.0.0');
      var filesArr := TJSONArray.Create;
      for var f in allFiles do
        filesArr.Add(ExtractFileName(f));
      manifestObj.AddPair('files', filesArr);

      manifestPath := baseDir + 'manifest.json';
      SafeWriteFile(manifestPath, manifestObj.Format(2), 'UTF-8');
      allFiles.Add(manifestPath);
    finally
      manifestObj.Free;
    end;

    // Convert list to array
    SetLength(Result.FilesGenerated, allFiles.Count);
    for var i := 0 to allFiles.Count - 1 do
      Result.FilesGenerated[i] := allFiles[i];

    Result.LineCount := FProject.Nodes.Count;
    Result.Success := Length(Result.Errors) = 0;
    AddLog('Package complete: ' + IntToStr(allFiles.Count) + ' files generated.');
  finally
    allFiles.Free;
  end;
end;

function SafeStr(const s: string): string;
begin
  Result := StringReplace(s, '-', '_', [rfReplaceAll]);
  Result := StringReplace(Result, '{', '', [rfReplaceAll]);
  Result := StringReplace(Result, '}', '', [rfReplaceAll]);
  Result := Copy(Result, 1, 16);
end;

end.
