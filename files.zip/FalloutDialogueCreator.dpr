program FalloutDialogueCreator;

uses
  Vcl.Forms,
  uMainForm in 'uMainForm.pas' {MainForm},
  uDialogueTypes in 'uDialogueTypes.pas',
  uNodeCanvas in 'uNodeCanvas.pas',
  uDialogueNode in 'uDialogueNode.pas',
  uSkillCheckEditor in 'uSkillCheckEditor.pas' {SkillCheckEditorForm},
  uNodeProperties in 'uNodeProperties.pas' {NodePropertiesForm},
  uPreviewSystem in 'uPreviewSystem.pas' {PreviewForm},
  uExportManager in 'uExportManager.pas',
  uProjectManager in 'uProjectManager.pas',
  uFloatMessageEditor in 'uFloatMessageEditor.pas' {FloatMessageForm},
  uValidationTools in 'uValidationTools.pas' {ValidationForm},
  uScriptEditor in 'uScriptEditor.pas' {ScriptEditorForm},
  uLocalization in 'uLocalization.pas' {LocalizationForm},
  uAssetBrowser in 'uAssetBrowser.pas' {AssetBrowserForm},
  uThemeManager in 'uThemeManager.pas',
  uSearchPanel in 'uSearchPanel.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.Title := 'Fallout Dialogue Creator';
  Application.CreateForm(TMainForm, MainForm);
  Application.Run;
end.
