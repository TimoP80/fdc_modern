unit uSkillCheckEditor;

interface

uses
  System.SysUtils, System.Classes, System.Math,
  Vcl.Forms, Vcl.Controls, Vcl.StdCtrls, Vcl.ComCtrls,
  Vcl.ExtCtrls, Vcl.Spin, Vcl.Graphics,
  uDialogueTypes, uThemeManager;

type
  TSkillCheckEditorForm = class(TForm)
  private
    FSkillCheck: TSkillCheck;
    FReadOnly: Boolean;

    pnlHeader: TPanel;
    lblTitle: TLabel;
    pnlBody: TPanel;
    pnlBottom: TPanel;
    btnOK: TButton;
    btnCancel: TButton;

    lblSkill: TLabel;
    cmbSkill: TComboBox;
    lblDiff: TLabel;
    trkDifficulty: TTrackBar;
    lblDiffVal: TLabel;
    lblProbability: TLabel;
    pnlProbBar: TPanel;
    pnlProbFill: TPanel;
    lblXP: TLabel;
    spnXP: TSpinEdit;
    lblCritBonus: TLabel;
    spnCritBonus: TSpinEdit;
    lblSuccessMsg: TLabel;
    edtSuccessMsg: TEdit;
    lblFailMsg: TLabel;
    edtFailMsg: TEdit;
    lblSuccessNode: TLabel;
    edtSuccessNode: TEdit;
    lblFailNode: TLabel;
    edtFailNode: TEdit;
    pnlSimulate: TPanel;
    lblSimTitle: TLabel;
    lblSimSkillVal: TLabel;
    spnSimSkill: TSpinEdit;
    btnSimulate: TButton;
    memoSimResult: TMemo;

    procedure BuildLayout;
    procedure StyleForm;
    procedure PopulateFromSkillCheck;
    procedure SaveToSkillCheck;
    procedure UpdateProbabilityBar;
    procedure trkDifficultyChange(Sender: TObject);
    procedure spnSimSkillChange(Sender: TObject);
    procedure btnSimulateClick(Sender: TObject);
    procedure btnOKClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  public
    class function Execute(AOwner: TComponent; var sk: TSkillCheck; readOnly: Boolean = False): Boolean;
    property SkillCheck: TSkillCheck read FSkillCheck write FSkillCheck;
  end;

implementation

class function TSkillCheckEditorForm.Execute(AOwner: TComponent; var sk: TSkillCheck;
  readOnly: Boolean): Boolean;
var frm: TSkillCheckEditorForm;
begin
  frm := TSkillCheckEditorForm.Create(AOwner);
  try
    frm.FSkillCheck := sk;
    frm.FReadOnly := readOnly;
    frm.PopulateFromSkillCheck;
    Result := frm.ShowModal = mrOk;
    if Result then
    begin
      frm.SaveToSkillCheck;
      sk := frm.FSkillCheck;
    end;
  finally frm.Free; end;
end;

procedure TSkillCheckEditorForm.FormCreate(Sender: TObject);
begin BuildLayout; StyleForm; end;

procedure TSkillCheckEditorForm.BuildLayout;
var sk: TSkillType;
begin
  Width := 520; Height := 560;
  Caption := 'Skill Check Editor';
  Position := poMainFormCenter;
  OnCreate := FormCreate;

  pnlHeader := TPanel.Create(Self); pnlHeader.Parent := Self;
  pnlHeader.Align := alTop; pnlHeader.Height := 38; pnlHeader.BevelOuter := bvNone;
  lblTitle := TLabel.Create(Self); lblTitle.Parent := pnlHeader;
  lblTitle.Left := 10; lblTitle.Top := 8;
  lblTitle.Caption := 'SKILL CHECK CONFIGURATION';
  lblTitle.Font.Size := 12; lblTitle.Font.Style := [fsBold];

  pnlBottom := TPanel.Create(Self); pnlBottom.Parent := Self;
  pnlBottom.Align := alBottom; pnlBottom.Height := 42; pnlBottom.BevelOuter := bvNone;
  btnOK := TButton.Create(Self); btnOK.Parent := pnlBottom;
  btnOK.Caption := 'OK'; btnOK.Left := pnlBottom.Width - 196; btnOK.Top := 7;
  btnOK.Width := 88; btnOK.Height := 28; btnOK.OnClick := btnOKClick;
  btnCancel := TButton.Create(Self); btnCancel.Parent := pnlBottom;
  btnCancel.Caption := 'Cancel'; btnCancel.ModalResult := mrCancel;
  btnCancel.Left := pnlBottom.Width - 100; btnCancel.Top := 7;
  btnCancel.Width := 88; btnCancel.Height := 28;
  btnOK.Anchors := [akRight, akTop]; btnCancel.Anchors := [akRight, akTop];

  pnlBody := TPanel.Create(Self); pnlBody.Parent := Self;
  pnlBody.Align := alClient; pnlBody.BevelOuter := bvNone;

  var y := 10;
  var lw := 120; var cx := 138; var cw := 280;

  procedure AL(const cap: string; top: Integer): TLabel;
  var l: TLabel; begin
    l := TLabel.Create(Self); l.Parent := pnlBody;
    l.Left := 6; l.Top := top + 3; l.Width := lw; l.Caption := cap;
    l.Alignment := taRightJustify; Result := l;
  end;

  AL('Skill:', y);
  cmbSkill := TComboBox.Create(Self); cmbSkill.Parent := pnlBody;
  cmbSkill.Left := cx; cmbSkill.Top := y; cmbSkill.Width := 200;
  cmbSkill.Style := csDropDownList;
  for sk := Low(TSkillType) to High(TSkillType) do cmbSkill.Items.Add(SKILL_NAMES[sk]);
  cmbSkill.ItemIndex := 0;
  Inc(y, 30);

  AL('Difficulty (1-100):', y);
  trkDifficulty := TTrackBar.Create(Self); trkDifficulty.Parent := pnlBody;
  trkDifficulty.Left := cx; trkDifficulty.Top := y; trkDifficulty.Width := 200;
  trkDifficulty.Min := 1; trkDifficulty.Max := 100; trkDifficulty.Position := 50;
  trkDifficulty.Frequency := 10; trkDifficulty.OnChange := trkDifficultyChange;
  lblDiffVal := TLabel.Create(Self); lblDiffVal.Parent := pnlBody;
  lblDiffVal.Left := cx + 208; lblDiffVal.Top := y + 6;
  lblDiffVal.Caption := '50%'; lblDiffVal.Width := 50; lblDiffVal.Font.Style := [fsBold];
  Inc(y, 36);

  AL('Success Probability:', y);
  pnlProbBar := TPanel.Create(Self); pnlProbBar.Parent := pnlBody;
  pnlProbBar.Left := cx; pnlProbBar.Top := y + 3;
  pnlProbBar.Width := 200; pnlProbBar.Height := 18;
  pnlProbBar.BevelOuter := bvLowered; pnlProbBar.BevelInner := bvNone;
  pnlProbFill := TPanel.Create(Self); pnlProbFill.Parent := pnlProbBar;
  pnlProbFill.Left := 0; pnlProbFill.Top := 0;
  pnlProbFill.Width := 100; pnlProbFill.Height := 18;
  pnlProbFill.BevelOuter := bvNone; pnlProbFill.Caption := '';
  lblProbability := TLabel.Create(Self); lblProbability.Parent := pnlBody;
  lblProbability.Left := cx + 208; lblProbability.Top := y + 3;
  lblProbability.Caption := '50%'; lblProbability.Width := 60;
  Inc(y, 30);

  AL('XP Reward:', y);
  spnXP := TSpinEdit.Create(Self); spnXP.Parent := pnlBody;
  spnXP.Left := cx; spnXP.Top := y; spnXP.Width := 100;
  spnXP.MinValue := 0; spnXP.MaxValue := 9999; spnXP.Value := 50;
  Inc(y, 30);

  AL('Crit. Success Bonus:', y);
  spnCritBonus := TSpinEdit.Create(Self); spnCritBonus.Parent := pnlBody;
  spnCritBonus.Left := cx; spnCritBonus.Top := y; spnCritBonus.Width := 100;
  spnCritBonus.MinValue := 0; spnCritBonus.MaxValue := 200; spnCritBonus.Value := 0;
  Inc(y, 30);

  AL('Success Message:', y);
  edtSuccessMsg := TEdit.Create(Self); edtSuccessMsg.Parent := pnlBody;
  edtSuccessMsg.Left := cx; edtSuccessMsg.Top := y; edtSuccessMsg.Width := cw;
  edtSuccessMsg.PlaceholderText := 'Optional success feedback message';
  Inc(y, 28);

  AL('Failure Message:', y);
  edtFailMsg := TEdit.Create(Self); edtFailMsg.Parent := pnlBody;
  edtFailMsg.Left := cx; edtFailMsg.Top := y; edtFailMsg.Width := cw;
  edtFailMsg.PlaceholderText := 'Optional failure feedback message';
  Inc(y, 28);

  AL('Success Node ID:', y);
  edtSuccessNode := TEdit.Create(Self); edtSuccessNode.Parent := pnlBody;
  edtSuccessNode.Left := cx; edtSuccessNode.Top := y; edtSuccessNode.Width := cw;
  edtSuccessNode.PlaceholderText := 'Target node ID on success';
  Inc(y, 28);

  AL('Failure Node ID:', y);
  edtFailNode := TEdit.Create(Self); edtFailNode.Parent := pnlBody;
  edtFailNode.Left := cx; edtFailNode.Top := y; edtFailNode.Width := cw;
  edtFailNode.PlaceholderText := 'Target node ID on failure';
  Inc(y, 38);

  // Simulation panel
  pnlSimulate := TPanel.Create(Self); pnlSimulate.Parent := pnlBody;
  pnlSimulate.Left := 6; pnlSimulate.Top := y;
  pnlSimulate.Width := pnlBody.Width - 12; pnlSimulate.Height := 110;
  pnlSimulate.BevelOuter := bvLowered; pnlSimulate.Caption := '';
  pnlSimulate.Anchors := [akLeft, akTop, akRight];

  lblSimTitle := TLabel.Create(Self); lblSimTitle.Parent := pnlSimulate;
  lblSimTitle.Left := 6; lblSimTitle.Top := 4;
  lblSimTitle.Caption := 'SIMULATION — Test skill check outcome';
  lblSimTitle.Font.Style := [fsBold]; lblSimTitle.Font.Size := 8;

  lblSimSkillVal := TLabel.Create(Self); lblSimSkillVal.Parent := pnlSimulate;
  lblSimSkillVal.Left := 6; lblSimSkillVal.Top := 26;
  lblSimSkillVal.Caption := 'Player skill value:'; lblSimSkillVal.Width := 110;

  spnSimSkill := TSpinEdit.Create(Self); spnSimSkill.Parent := pnlSimulate;
  spnSimSkill.Left := 120; spnSimSkill.Top := 22; spnSimSkill.Width := 80;
  spnSimSkill.MinValue := 1; spnSimSkill.MaxValue := 200; spnSimSkill.Value := 40;
  spnSimSkill.OnChange := spnSimSkillChange;

  btnSimulate := TButton.Create(Self); btnSimulate.Parent := pnlSimulate;
  btnSimulate.Caption := '🎲 Roll 10x';
  btnSimulate.Left := 210; btnSimulate.Top := 22;
  btnSimulate.Width := 90; btnSimulate.Height := 26;
  btnSimulate.OnClick := btnSimulateClick;

  memoSimResult := TMemo.Create(Self); memoSimResult.Parent := pnlSimulate;
  memoSimResult.Left := 6; memoSimResult.Top := 54;
  memoSimResult.Width := pnlSimulate.Width - 12; memoSimResult.Height := 48;
  memoSimResult.ReadOnly := True; memoSimResult.ScrollBars := ssHorizontal;
  memoSimResult.Anchors := [akLeft, akTop, akRight];
  memoSimResult.Font.Name := 'Courier New'; memoSimResult.Font.Size := 8;
end;

procedure TSkillCheckEditorForm.StyleForm;
var t: TFDCTheme;
begin
  t := TThemeManager.Current;
  Color := t.BgDark; Font.Color := t.TextPrimary; Font.Name := t.FontName;
  pnlHeader.Color := t.BgMedium; pnlBottom.Color := t.BgMedium;
  pnlBody.Color := t.BgDark;
  lblTitle.Font.Color := t.AccentPrimary;
  cmbSkill.Color := t.BgLight; cmbSkill.Font.Color := t.TextPrimary;
  edtSuccessMsg.Color := t.BgLight; edtSuccessMsg.Font.Color := t.TextPrimary;
  edtFailMsg.Color := t.BgLight; edtFailMsg.Font.Color := t.TextPrimary;
  edtSuccessNode.Color := t.BgLight; edtSuccessNode.Font.Color := t.TextPrimary;
  edtFailNode.Color := t.BgLight; edtFailNode.Font.Color := t.TextPrimary;
  pnlProbBar.Color := t.BgMedium;
  pnlProbFill.Color := t.ColorSuccess;
  lblDiffVal.Font.Color := t.AccentPrimary;
  lblProbability.Font.Color := t.AccentPrimary;
  pnlSimulate.Color := t.BgMedium;
  lblSimTitle.Font.Color := t.AccentSecondary;
  memoSimResult.Color := t.BgDark; memoSimResult.Font.Color := t.TextPrimary;
  for var i := 0 to pnlBody.ControlCount - 1 do
    if pnlBody.Controls[i] is TLabel then
      (pnlBody.Controls[i] as TLabel).Font.Color := t.TextSecondary;
end;

procedure TSkillCheckEditorForm.PopulateFromSkillCheck;
begin
  cmbSkill.ItemIndex := Ord(FSkillCheck.Skill);
  trkDifficulty.Position := Max(1, Min(100, FSkillCheck.Difficulty));
  spnXP.Value := FSkillCheck.XPReward;
  spnCritBonus.Value := FSkillCheck.CritSuccessBonus;
  edtSuccessMsg.Text := FSkillCheck.SuccessMessage;
  edtFailMsg.Text := FSkillCheck.FailureMessage;
  edtSuccessNode.Text := FSkillCheck.SuccessNodeID;
  edtFailNode.Text := FSkillCheck.FailureNodeID;
  UpdateProbabilityBar;
end;

procedure TSkillCheckEditorForm.SaveToSkillCheck;
begin
  FSkillCheck.Skill := TSkillType(cmbSkill.ItemIndex);
  FSkillCheck.Difficulty := trkDifficulty.Position;
  FSkillCheck.XPReward := spnXP.Value;
  FSkillCheck.CritSuccessBonus := spnCritBonus.Value;
  FSkillCheck.SuccessMessage := edtSuccessMsg.Text;
  FSkillCheck.FailureMessage := edtFailMsg.Text;
  FSkillCheck.SuccessNodeID := edtSuccessNode.Text;
  FSkillCheck.FailureNodeID := edtFailNode.Text;
end;

procedure TSkillCheckEditorForm.UpdateProbabilityBar;
var
  skill, diff, chance: Integer;
begin
  skill := spnSimSkill.Value;
  diff := trkDifficulty.Position;
  chance := Max(5, Min(95, skill - diff + 50));
  lblDiffVal.Caption := IntToStr(diff) + '%';
  lblProbability.Caption := IntToStr(chance) + '%';
  pnlProbFill.Width := Round(pnlProbBar.Width * chance / 100);
  if chance >= 70 then pnlProbFill.Color := TThemeManager.Current.ColorSuccess
  else if chance >= 40 then pnlProbFill.Color := TThemeManager.Current.ColorWarning
  else pnlProbFill.Color := TThemeManager.Current.ColorError;
end;

procedure TSkillCheckEditorForm.trkDifficultyChange(Sender: TObject);
begin UpdateProbabilityBar; end;

procedure TSkillCheckEditorForm.spnSimSkillChange(Sender: TObject);
begin UpdateProbabilityBar; end;

procedure TSkillCheckEditorForm.btnSimulateClick(Sender: TObject);
var
  skill, diff, chance, roll, pass, fail, i: Integer;
  results: string;
begin
  skill := spnSimSkill.Value;
  diff := trkDifficulty.Position;
  chance := Max(5, Min(95, skill - diff + 50));
  pass := 0; fail := 0;
  results := '';
  for i := 1 to 10 do
  begin
    roll := Random(100) + 1;
    if roll <= chance then begin Inc(pass); results := results + '✓'; end
    else begin Inc(fail); results := results + '✗'; end;
  end;
  memoSimResult.Text := results + '  →  Pass: ' + IntToStr(pass) + '/10  Fail: ' + IntToStr(fail) + '/10' +
    sLineBreak + 'Chance: ' + IntToStr(chance) + '%  Skill: ' + IntToStr(skill) +
    '  Difficulty: ' + IntToStr(diff);
end;

procedure TSkillCheckEditorForm.btnOKClick(Sender: TObject);
begin SaveToSkillCheck; ModalResult := mrOk; end;

initialization
  RegisterClass(TSkillCheckEditorForm);
  Randomize;
end.

{ ============================================================ }

unit uScriptEditor;

interface

uses
  System.SysUtils, System.Classes,
  Vcl.Forms, Vcl.Controls, Vcl.StdCtrls, Vcl.ComCtrls,
  Vcl.ExtCtrls, Vcl.Buttons, Vcl.Graphics,
  uDialogueTypes, uThemeManager;

type
  TScriptEditorForm = class(TForm)
  private
    FScriptCode: string;
    pnlHeader: TPanel;
    lblTitle: TLabel;
    pnlBottom: TPanel;
    btnOK: TButton;
    btnCancel: TButton;
    btnValidate: TButton;
    pcScript: TPageControl;
    tsEditor: TTabSheet;
    tsReference: TTabSheet;
    memoEditor: TMemo;
    memoReference: TMemo;
    pnlToolbar: TPanel;
    cmbEventType: TComboBox;
    lblEvent: TLabel;
    btnInsertTemplate: TButton;
    lblLineInfo: TLabel;
    procedure BuildLayout;
    procedure StyleForm;
    procedure LoadReference;
    procedure ValidateScript;
    procedure InsertTemplate;
    procedure memoEditorKeyUp(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure btnOKClick(Sender: TObject);
    procedure btnValidateClick(Sender: TObject);
    procedure btnInsertTemplateClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  public
    class function Execute(AOwner: TComponent; var code: string): Boolean;
  end;

implementation

class function TScriptEditorForm.Execute(AOwner: TComponent; var code: string): Boolean;
var frm: TScriptEditorForm;
begin
  frm := TScriptEditorForm.Create(AOwner);
  try
    frm.FScriptCode := code;
    frm.memoEditor.Text := code;
    Result := frm.ShowModal = mrOk;
    if Result then code := frm.memoEditor.Text;
  finally frm.Free; end;
end;

procedure TScriptEditorForm.FormCreate(Sender: TObject);
begin BuildLayout; StyleForm; LoadReference; end;

procedure TScriptEditorForm.BuildLayout;
var se: TScriptEvent;
begin
  Width := 720; Height := 580;
  Caption := 'Script Editor';
  Position := poMainFormCenter;
  OnCreate := FormCreate;

  pnlHeader := TPanel.Create(Self); pnlHeader.Parent := Self;
  pnlHeader.Align := alTop; pnlHeader.Height := 38; pnlHeader.BevelOuter := bvNone;
  lblTitle := TLabel.Create(Self); lblTitle.Parent := pnlHeader;
  lblTitle.Left := 10; lblTitle.Top := 8;
  lblTitle.Caption := 'SCRIPT EDITOR';
  lblTitle.Font.Size := 12; lblTitle.Font.Style := [fsBold];

  pnlToolbar := TPanel.Create(Self); pnlToolbar.Parent := Self;
  pnlToolbar.Align := alTop; pnlToolbar.Height := 34; pnlToolbar.BevelOuter := bvNone;

  lblEvent := TLabel.Create(Self); lblEvent.Parent := pnlToolbar;
  lblEvent.Left := 6; lblEvent.Top := 8; lblEvent.Caption := 'Event:';

  cmbEventType := TComboBox.Create(Self); cmbEventType.Parent := pnlToolbar;
  cmbEventType.Left := 52; cmbEventType.Top := 5;
  cmbEventType.Width := 200; cmbEventType.Style := csDropDownList;
  for se := Low(TScriptEvent) to High(TScriptEvent) do
    cmbEventType.Items.Add(GetEnumName(TypeInfo(TScriptEvent), Ord(se)));
  cmbEventType.ItemIndex := 0;

  btnInsertTemplate := TButton.Create(Self); btnInsertTemplate.Parent := pnlToolbar;
  btnInsertTemplate.Caption := 'Insert Template';
  btnInsertTemplate.Left := 260; btnInsertTemplate.Top := 4;
  btnInsertTemplate.Width := 120; btnInsertTemplate.Height := 26;
  btnInsertTemplate.OnClick := btnInsertTemplateClick;

  lblLineInfo := TLabel.Create(Self); lblLineInfo.Parent := pnlToolbar;
  lblLineInfo.Left := 400; lblLineInfo.Top := 8;
  lblLineInfo.Caption := 'Ln 1  Col 1'; lblLineInfo.Width := 200;

  pnlBottom := TPanel.Create(Self); pnlBottom.Parent := Self;
  pnlBottom.Align := alBottom; pnlBottom.Height := 42; pnlBottom.BevelOuter := bvNone;

  btnOK := TButton.Create(Self); btnOK.Parent := pnlBottom;
  btnOK.Caption := 'OK'; btnOK.Left := pnlBottom.Width - 196; btnOK.Top := 7;
  btnOK.Width := 88; btnOK.Height := 28; btnOK.OnClick := btnOKClick;
  btnOK.Anchors := [akRight, akTop];

  btnCancel := TButton.Create(Self); btnCancel.Parent := pnlBottom;
  btnCancel.Caption := 'Cancel'; btnCancel.ModalResult := mrCancel;
  btnCancel.Left := pnlBottom.Width - 100; btnCancel.Top := 7;
  btnCancel.Width := 88; btnCancel.Height := 28; btnCancel.Anchors := [akRight, akTop];

  btnValidate := TButton.Create(Self); btnValidate.Parent := pnlBottom;
  btnValidate.Caption := '✓ Validate Script';
  btnValidate.Left := 6; btnValidate.Top := 7;
  btnValidate.Width := 130; btnValidate.Height := 28;
  btnValidate.OnClick := btnValidateClick;

  pcScript := TPageControl.Create(Self); pcScript.Parent := Self;
  pcScript.Align := alClient;

  tsEditor := TTabSheet.Create(pcScript);
  tsEditor.PageControl := pcScript; tsEditor.Caption := 'Script Code';

  memoEditor := TMemo.Create(Self); memoEditor.Parent := tsEditor;
  memoEditor.Align := alClient; memoEditor.ScrollBars := ssBoth;
  memoEditor.WordWrap := False; memoEditor.Font.Name := 'Courier New';
  memoEditor.Font.Size := 10; memoEditor.OnKeyUp := memoEditorKeyUp;

  tsReference := TTabSheet.Create(pcScript);
  tsReference.PageControl := pcScript; tsReference.Caption := 'Function Reference';

  memoReference := TMemo.Create(Self); memoReference.Parent := tsReference;
  memoReference.Align := alClient; memoReference.ReadOnly := True;
  memoReference.ScrollBars := ssBoth; memoReference.WordWrap := False;
  memoReference.Font.Name := 'Courier New'; memoReference.Font.Size := 9;
end;

procedure TScriptEditorForm.StyleForm;
var t: TFDCTheme;
begin
  t := TThemeManager.Current;
  Color := t.BgDark; Font.Color := t.TextPrimary;
  pnlHeader.Color := t.BgMedium; pnlBottom.Color := t.BgMedium; pnlToolbar.Color := t.BgMedium;
  lblTitle.Font.Color := t.AccentPrimary;
  lblEvent.Font.Color := t.TextSecondary;
  lblLineInfo.Font.Color := t.TextDim; lblLineInfo.Font.Size := 8;
  memoEditor.Color := t.BgDark; memoEditor.Font.Color := t.AccentPrimary;
  memoReference.Color := t.BgDark; memoReference.Font.Color := t.TextSecondary;
  cmbEventType.Color := t.BgLight; cmbEventType.Font.Color := t.TextPrimary;
  pcScript.Color := t.BgDark;
end;

procedure TScriptEditorForm.LoadReference;
begin
  memoReference.Lines.Clear;
  memoReference.Lines.Add('=== FALLOUT DIALOGUE SCRIPT REFERENCE ===');
  memoReference.Lines.Add('');
  memoReference.Lines.Add('--- PLAYER / NPC ACCESS ---');
  memoReference.Lines.Add('  player                    // Player object');
  memoReference.Lines.Add('  npc                       // Current NPC object');
  memoReference.Lines.Add('  player.skill[SPEECH]      // Get player skill value (0-300)');
  memoReference.Lines.Add('  player.stat[ST]           // Get SPECIAL stat');
  memoReference.Lines.Add('  player.karma              // Get karma points');
  memoReference.Lines.Add('  player.reputation         // Get reputation with faction');
  memoReference.Lines.Add('');
  memoReference.Lines.Add('--- VARIABLES ---');
  memoReference.Lines.Add('  global_var("VAR_NAME")    // Read global variable');
  memoReference.Lines.Add('  set_global_var("VAR", v)  // Set global variable');
  memoReference.Lines.Add('  local_var("VAR_NAME")     // Read local (NPC) variable');
  memoReference.Lines.Add('  set_local_var("VAR", v)   // Set local variable');
  memoReference.Lines.Add('');
  memoReference.Lines.Add('--- QUEST SYSTEM ---');
  memoReference.Lines.Add('  quest_state("QUEST_ID")   // Get quest state (0=none,1=active,2=done)');
  memoReference.Lines.Add('  set_quest("QUEST_ID", s)  // Set quest state');
  memoReference.Lines.Add('  add_journal("QUEST_ID", e)// Add journal entry');
  memoReference.Lines.Add('');
  memoReference.Lines.Add('--- INVENTORY ---');
  memoReference.Lines.Add('  has_item(player, "ITEM")  // Check if player has item');
  memoReference.Lines.Add('  give_item(player, "ITEM") // Give item to player');
  memoReference.Lines.Add('  take_item(player, "ITEM") // Remove item from player');
  memoReference.Lines.Add('  give_caps(player, amount) // Give bottle caps');
  memoReference.Lines.Add('  take_caps(player, amount) // Remove caps');
  memoReference.Lines.Add('');
  memoReference.Lines.Add('--- REPUTATION / KARMA ---');
  memoReference.Lines.Add('  modify_karma(amount)      // Change karma (+/-)');
  memoReference.Lines.Add('  modify_rep("FACTION", v)  // Change faction reputation');
  memoReference.Lines.Add('  give_xp(amount)           // Award experience points');
  memoReference.Lines.Add('');
  memoReference.Lines.Add('--- DIALOGUE CONTROL ---');
  memoReference.Lines.Add('  end_dialogue()            // End conversation');
  memoReference.Lines.Add('  goto_node("NODE_ID")      // Jump to dialogue node');
  memoReference.Lines.Add('  set_npc_attitude(v)       // 0=hostile,50=neutral,100=friendly');
  memoReference.Lines.Add('');
  memoReference.Lines.Add('--- COMBAT ---');
  memoReference.Lines.Add('  start_combat()            // Trigger combat');
  memoReference.Lines.Add('  flee_combat()             // NPC flees');
  memoReference.Lines.Add('');
  memoReference.Lines.Add('--- EVENTS ---');
  memoReference.Lines.Add('  OnDialogueStart  // Fired when dialogue begins');
  memoReference.Lines.Add('  OnNodeEnter      // Fired when entering any node');
  memoReference.Lines.Add('  OnOptionSelected // Fired when player picks option');
  memoReference.Lines.Add('  OnSkillCheck     // Fired during skill check');
  memoReference.Lines.Add('  OnQuestUpdate    // Fired when quest state changes');
  memoReference.Lines.Add('  OnCombatStart    // Fired when combat begins');
  memoReference.Lines.Add('  OnDialogueEnd    // Fired at conversation end');
end;

procedure TScriptEditorForm.ValidateScript;
var
  issues: TStringList;
  code: string;
begin
  code := memoEditor.Text;
  issues := TStringList.Create;
  try
    if Trim(code) = '' then begin issues.Add('WARNING: Empty script'); end;
    if Pos('procedure', LowerCase(code)) > 0 then issues.Add('OK: Found procedure definition(s)');
    if Pos('end;', LowerCase(code)) > 0 then issues.Add('OK: Found end statement(s)');
    if Pos('begin', LowerCase(code)) > 0 then issues.Add('OK: Found begin block(s)');
    if issues.Count = 0 then issues.Add('Script appears valid (basic check).');
    ShowMessage('Script Validation:' + sLineBreak + issues.Text);
  finally issues.Free; end;
end;

procedure TScriptEditorForm.InsertTemplate;
var
  tmpl: string;
  se: TScriptEvent;
begin
  se := TScriptEvent(cmbEventType.ItemIndex);
  case se of
    seOnDialogueStart:
      tmpl := 'procedure OnDialogueStart(npc, player: TEntity);' + sLineBreak +
              'begin' + sLineBreak +
              '  // Called when dialogue begins' + sLineBreak +
              '  set_npc_attitude(50);  // Neutral' + sLineBreak +
              'end;';
    seOnNodeEnter:
      tmpl := 'procedure OnNodeEnter(npc, player: TEntity; nodeID: string);' + sLineBreak +
              'begin' + sLineBreak +
              '  // Called when entering this node' + sLineBreak +
              'end;';
    seOnOptionSelected:
      tmpl := 'procedure OnOptionSelected(player: TEntity; optionIndex: Integer);' + sLineBreak +
              'begin' + sLineBreak +
              '  // Called when player selects an option' + sLineBreak +
              '  case optionIndex of' + sLineBreak +
              '    0: give_xp(25);' + sLineBreak +
              '    1: modify_karma(10);' + sLineBreak +
              '  end;' + sLineBreak +
              'end;';
    seOnSkillCheck:
      tmpl := 'procedure OnSkillCheck(skill: string; playerVal, difficulty: Integer; passed: Boolean);' + sLineBreak +
              'begin' + sLineBreak +
              '  if passed then' + sLineBreak +
              '    give_xp(50)' + sLineBreak +
              '  else' + sLineBreak +
              '    set_local_var("LVAR_FAILED_CHECK", 1);' + sLineBreak +
              'end;';
    seOnQuestUpdate:
      tmpl := 'procedure OnQuestUpdate(questID: string; newState: Integer);' + sLineBreak +
              'begin' + sLineBreak +
              '  // Quest state changed' + sLineBreak +
              '  add_journal(questID, newState);' + sLineBreak +
              'end;';
    seOnCombatStart:
      tmpl := 'procedure OnCombatStart(npc, player: TEntity);' + sLineBreak +
              'begin' + sLineBreak +
              '  // Triggered when combat begins from dialogue' + sLineBreak +
              '  start_combat();' + sLineBreak +
              'end;';
    seOnDialogueEnd:
      tmpl := 'procedure OnDialogueEnd(npc, player: TEntity);' + sLineBreak +
              'begin' + sLineBreak +
              '  // Cleanup after dialogue ends' + sLineBreak +
              '  set_global_var("GVAR_MET_NPC", 1);' + sLineBreak +
              'end;';
  else
    tmpl := '// Script template' + sLineBreak + 'begin' + sLineBreak + 'end;';
  end;
  memoEditor.Lines.Add('');
  memoEditor.Lines.Add(tmpl);
end;

procedure TScriptEditorForm.memoEditorKeyUp(Sender: TObject; var Key: Word; Shift: TShiftState);
var row, col: Integer;
begin
  row := memoEditor.CaretPos.Y + 1;
  col := memoEditor.CaretPos.X + 1;
  lblLineInfo.Caption := 'Ln ' + IntToStr(row) + '  Col ' + IntToStr(col) +
    '  Lines: ' + IntToStr(memoEditor.Lines.Count);
end;

procedure TScriptEditorForm.btnOKClick(Sender: TObject); begin ModalResult := mrOk; end;
procedure TScriptEditorForm.btnValidateClick(Sender: TObject); begin ValidateScript; end;
procedure TScriptEditorForm.btnInsertTemplateClick(Sender: TObject); begin InsertTemplate; end;

initialization
  RegisterClass(TScriptEditorForm);
end.

{ ============================================================ }

unit uLocalization;

interface

uses
  System.SysUtils, System.Classes, System.JSON,
  Vcl.Forms, Vcl.Controls, Vcl.StdCtrls, Vcl.ComCtrls,
  Vcl.ExtCtrls, Vcl.Dialogs,
  uDialogueTypes, uThemeManager, uExportManager;

type
  TLocalizationForm = class(TForm)
  private
    FProject: TDialogueProject;
    pnlTop, pnlBottom: TPanel;
    lblTitle: TLabel;
    lstLocales: TListBox;
    btnAddLocale, btnRemLocale, btnExport, btnImport, btnClose: TButton;
    lvStrings: TListView;
    lblStats: TLabel;
    procedure BuildLayout;
    procedure StyleForm;
    procedure RefreshLocales;
    procedure RefreshStrings;
    procedure btnAddLocaleClick(Sender: TObject);
    procedure btnRemLocaleClick(Sender: TObject);
    procedure btnExportClick(Sender: TObject);
    procedure btnImportClick(Sender: TObject);
    procedure lstLocalesClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormShow(Sender: TObject);
  public
    class procedure Execute(AOwner: TComponent; aProject: TDialogueProject);
  end;

implementation

class procedure TLocalizationForm.Execute(AOwner: TComponent; aProject: TDialogueProject);
var frm: TLocalizationForm;
begin
  frm := TLocalizationForm.Create(AOwner);
  try frm.FProject := aProject; frm.ShowModal;
  finally frm.Free; end;
end;

procedure TLocalizationForm.FormCreate(Sender: TObject); begin BuildLayout; StyleForm; end;
procedure TLocalizationForm.FormShow(Sender: TObject); begin RefreshLocales; RefreshStrings; end;

procedure TLocalizationForm.BuildLayout;
begin
  Width := 780; Height := 520;
  Caption := 'Localization Manager';
  Position := poMainFormCenter;
  OnCreate := FormCreate; OnShow := FormShow;

  pnlTop := TPanel.Create(Self); pnlTop.Parent := Self;
  pnlTop.Align := alTop; pnlTop.Height := 40; pnlTop.BevelOuter := bvNone;
  lblTitle := TLabel.Create(Self); lblTitle.Parent := pnlTop;
  lblTitle.Left := 10; lblTitle.Top := 8;
  lblTitle.Caption := 'LOCALIZATION MANAGER';
  lblTitle.Font.Size := 12; lblTitle.Font.Style := [fsBold];

  pnlBottom := TPanel.Create(Self); pnlBottom.Parent := Self;
  pnlBottom.Align := alBottom; pnlBottom.Height := 42; pnlBottom.BevelOuter := bvNone;

  lblStats := TLabel.Create(Self); lblStats.Parent := pnlBottom;
  lblStats.Left := 6; lblStats.Top := 12; lblStats.Caption := 'Strings: 0'; lblStats.Width := 200;

  btnExport := TButton.Create(Self); btnExport.Parent := pnlBottom;
  btnExport.Caption := '⬆ Export Pack'; btnExport.Left := 220; btnExport.Top := 7;
  btnExport.Width := 110; btnExport.Height := 28; btnExport.OnClick := btnExportClick;

  btnImport := TButton.Create(Self); btnImport.Parent := pnlBottom;
  btnImport.Caption := '⬇ Import Pack'; btnImport.Left := 338; btnImport.Top := 7;
  btnImport.Width := 110; btnImport.Height := 28; btnImport.OnClick := btnImportClick;

  btnClose := TButton.Create(Self); btnClose.Parent := pnlBottom;
  btnClose.Caption := 'Done'; btnClose.ModalResult := mrOk;
  btnClose.Anchors := [akRight, akTop];
  btnClose.Left := pnlBottom.Width - 96; btnClose.Top := 7;
  btnClose.Width := 90; btnClose.Height := 28;

  var pnlLocales := TPanel.Create(Self); pnlLocales.Parent := Self;
  pnlLocales.Align := alLeft; pnlLocales.Width := 180; pnlLocales.BevelOuter := bvNone;

  var locHdr := TLabel.Create(Self); locHdr.Parent := pnlLocales;
  locHdr.Left := 4; locHdr.Top := 4; locHdr.Caption := 'LOCALES'; locHdr.Font.Style := [fsBold];

  lstLocales := TListBox.Create(Self); lstLocales.Parent := pnlLocales;
  lstLocales.Left := 0; lstLocales.Top := 24; lstLocales.Width := 180;
  lstLocales.Height := pnlLocales.Height - 70;
  lstLocales.Anchors := [akLeft, akTop, akRight, akBottom];
  lstLocales.OnClick := lstLocalesClick;

  var locBtnPanel := TPanel.Create(Self); locBtnPanel.Parent := pnlLocales;
  locBtnPanel.Align := alBottom; locBtnPanel.Height := 36; locBtnPanel.BevelOuter := bvNone;

  btnAddLocale := TButton.Create(Self); btnAddLocale.Parent := locBtnPanel;
  btnAddLocale.Caption := '+'; btnAddLocale.Left := 4; btnAddLocale.Top := 4;
  btnAddLocale.Width := 40; btnAddLocale.Height := 26; btnAddLocale.OnClick := btnAddLocaleClick;

  btnRemLocale := TButton.Create(Self); btnRemLocale.Parent := locBtnPanel;
  btnRemLocale.Caption := '−'; btnRemLocale.Left := 48; btnRemLocale.Top := 4;
  btnRemLocale.Width := 40; btnRemLocale.Height := 26; btnRemLocale.OnClick := btnRemLocaleClick;

  var sp := TSplitter.Create(Self); sp.Parent := Self;
  sp.Align := alLeft; sp.Width := 4;

  var pnlStrings := TPanel.Create(Self); pnlStrings.Parent := Self;
  pnlStrings.Align := alClient; pnlStrings.BevelOuter := bvNone;

  lvStrings := TListView.Create(Self); lvStrings.Parent := pnlStrings;
  lvStrings.Align := alClient; lvStrings.ViewStyle := vsReport;
  lvStrings.RowSelect := True; lvStrings.GridLines := True;
  with lvStrings.Columns.Add do begin Caption := 'Key'; Width := 180; end;
  with lvStrings.Columns.Add do begin Caption := 'Source (en-US)'; Width := 260; end;
  with lvStrings.Columns.Add do begin Caption := 'Translation'; Width := 260; end;
  with lvStrings.Columns.Add do begin Caption := 'Status'; Width := 80; end;
end;

procedure TLocalizationForm.StyleForm;
var t: TFDCTheme;
begin
  t := TThemeManager.Current;
  Color := t.BgDark; Font.Color := t.TextPrimary;
  pnlTop.Color := t.BgMedium; pnlBottom.Color := t.BgMedium;
  lblTitle.Font.Color := t.AccentPrimary;
  lstLocales.Color := t.BgDark; lstLocales.Font.Color := t.TextPrimary;
  lvStrings.Color := t.BgDark; lvStrings.Font.Color := t.TextPrimary;
  lblStats.Font.Color := t.TextSecondary;
end;

procedure TLocalizationForm.RefreshLocales;
begin
  lstLocales.Items.Clear;
  if not Assigned(FProject) then Exit;
  for var locale in FProject.Locales do lstLocales.Items.Add(locale);
  if lstLocales.Items.Count > 0 then lstLocales.ItemIndex := 0;
end;

procedure TLocalizationForm.RefreshStrings;
var
  node: TDialogueNode;
  item: TListItem;
  count: Integer;
begin
  lvStrings.Items.Clear;
  if not Assigned(FProject) then Exit;
  count := 0;
  for node in FProject.Nodes do
  begin
    if (node.NodeType = ntComment) or (Trim(node.Text) = '') then Continue;
    item := lvStrings.Items.Add;
    item.Caption := 'node_' + Copy(node.ID, 1, 10) + '_text';
    item.SubItems.Add(Copy(node.Text, 1, 80));
    item.SubItems.Add(Copy(node.Text, 1, 80));  // Placeholder translation
    item.SubItems.Add('Untranslated');
    Inc(count);
    for var i := 0 to node.PlayerOptions.Count - 1 do
    begin
      if Trim(node.PlayerOptions[i].Text) = '' then Continue;
      item := lvStrings.Items.Add;
      item.Caption := 'node_' + Copy(node.ID, 1, 10) + '_opt' + IntToStr(i);
      item.SubItems.Add(Copy(node.PlayerOptions[i].Text, 1, 80));
      item.SubItems.Add(Copy(node.PlayerOptions[i].Text, 1, 80));
      item.SubItems.Add('Untranslated');
      Inc(count);
    end;
  end;
  lblStats.Caption := 'Total strings: ' + IntToStr(count);
end;

procedure TLocalizationForm.lstLocalesClick(Sender: TObject);
begin
  if lstLocales.ItemIndex >= 0 then
    FProject.ActiveLocale := lstLocales.Items[lstLocales.ItemIndex];
  RefreshStrings;
end;

procedure TLocalizationForm.btnAddLocaleClick(Sender: TObject);
var locale: string;
begin
  locale := InputBox('Add Locale', 'Locale code (e.g. de-DE, fr-FR, ru-RU):', '');
  if Trim(locale) = '' then Exit;
  if FProject.Locales.IndexOf(locale) < 0 then
  begin
    FProject.Locales.Add(locale);
    FProject.Modified := True;
    RefreshLocales;
  end;
end;

procedure TLocalizationForm.btnRemLocaleClick(Sender: TObject);
begin
  if lstLocales.ItemIndex <= 0 then begin ShowMessage('Cannot remove default locale.'); Exit; end;
  FProject.Locales.Delete(lstLocales.ItemIndex);
  FProject.Modified := True;
  RefreshLocales;
end;

procedure TLocalizationForm.btnExportClick(Sender: TObject);
var
  dlg: TSaveDialog;
  opts: TExportOptions;
  mgr: TExportManager;
  res: TExportResult;
begin
  dlg := TSaveDialog.Create(nil);
  try
    dlg.Filter := 'Localization JSON|*.json|All Files|*.*';
    dlg.Title := 'Export Localization Pack';
    dlg.FileName := FProject.NPCName + '_' + FProject.ActiveLocale;
    if not dlg.Execute then Exit;
    opts := TExportManager.DefaultOptions;
    opts.Format := efLocalization;
    opts.OutputPath := dlg.FileName;
    opts.LocaleFilter := FProject.ActiveLocale;
    mgr := TExportManager.Create(FProject);
    try
      res := mgr.Export(opts);
      if res.Success then
        ShowMessage('Exported ' + IntToStr(Length(res.FilesGenerated)) + ' file(s) successfully.')
      else
        ShowMessage('Export failed: ' + string.Join(sLineBreak, res.Errors));
    finally mgr.Free; end;
  finally dlg.Free; end;
end;

procedure TLocalizationForm.btnImportClick(Sender: TObject);
var
  dlg: TOpenDialog;
  sl: TStringList;
  jsonObj: TJSONObject;
  arr: TJSONArray;
  i: Integer;
begin
  dlg := TOpenDialog.Create(nil);
  try
    dlg.Filter := 'Localization JSON|*.json|All Files|*.*';
    dlg.Title := 'Import Localization Pack';
    if not dlg.Execute then Exit;
    sl := TStringList.Create;
    try
      sl.LoadFromFile(dlg.FileName, TEncoding.UTF8);
      jsonObj := TJSONObject.ParseJSONValue(sl.Text) as TJSONObject;
      if Assigned(jsonObj) then
      try
        ShowMessage('Localization file loaded successfully.' + sLineBreak +
          'Found ' + IntToStr((jsonObj.GetValue('count') as TJSONNumber).AsInt) + ' strings.');
      finally jsonObj.Free; end;
    finally sl.Free; end;
  finally dlg.Free; end;
end;

initialization
  RegisterClass(TLocalizationForm);
end.

{ ============================================================ }

unit uAssetBrowser;

interface

uses
  System.SysUtils, System.Classes, System.IOUtils,
  Vcl.Forms, Vcl.Controls, Vcl.StdCtrls, Vcl.ComCtrls,
  Vcl.ExtCtrls, Vcl.Dialogs, Vcl.Graphics, Vcl.Imaging.PNGImage,
  uThemeManager;

type
  TAssetBrowserForm = class(TForm)
  private
    pnlTop, pnlBottom: TPanel;
    lblTitle, lblPath: TLabel;
    tvAssets: TTreeView;
    imgPreview: TImage;
    btnBrowseFolder: TButton;
    btnClose: TButton;
    btnSelect: TButton;
    cmbFilter: TComboBox;
    splitter: TSplitter;
    pnlPreview: TPanel;
    pnlList: TPanel;
    FSelectedFile: string;
    FRootPath: string;
    procedure BuildLayout;
    procedure StyleForm;
    procedure PopulateTree(const path: string);
    procedure tvAssetsClick(Sender: TObject);
    procedure btnBrowseFolderClick(Sender: TObject);
    procedure btnSelectClick(Sender: TObject);
    procedure cmbFilterChange(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  public
    class function Execute(AOwner: TComponent; const rootPath: string;
      out selectedFile: string): Boolean;
    property SelectedFile: string read FSelectedFile;
  end;

implementation

class function TAssetBrowserForm.Execute(AOwner: TComponent; const rootPath: string;
  out selectedFile: string): Boolean;
var frm: TAssetBrowserForm;
begin
  frm := TAssetBrowserForm.Create(AOwner);
  try
    frm.FRootPath := rootPath;
    if rootPath <> '' then frm.PopulateTree(rootPath);
    Result := frm.ShowModal = mrOk;
    selectedFile := frm.FSelectedFile;
  finally frm.Free; end;
end;

procedure TAssetBrowserForm.FormCreate(Sender: TObject); begin BuildLayout; StyleForm; end;

procedure TAssetBrowserForm.BuildLayout;
begin
  Width := 640; Height := 500;
  Caption := 'Asset Browser';
  Position := poMainFormCenter;
  OnCreate := FormCreate;

  pnlTop := TPanel.Create(Self); pnlTop.Parent := Self;
  pnlTop.Align := alTop; pnlTop.Height := 72; pnlTop.BevelOuter := bvNone;

  lblTitle := TLabel.Create(Self); lblTitle.Parent := pnlTop;
  lblTitle.Left := 10; lblTitle.Top := 6;
  lblTitle.Caption := 'ASSET BROWSER';
  lblTitle.Font.Size := 12; lblTitle.Font.Style := [fsBold];

  var filterLbl := TLabel.Create(Self); filterLbl.Parent := pnlTop;
  filterLbl.Left := 10; filterLbl.Top := 32; filterLbl.Caption := 'Filter:'; filterLbl.Width := 40;

  cmbFilter := TComboBox.Create(Self); cmbFilter.Parent := pnlTop;
  cmbFilter.Left := 52; cmbFilter.Top := 28; cmbFilter.Width := 180;
  cmbFilter.Style := csDropDownList;
  cmbFilter.Items.AddStrings(['All Assets', 'Images (*.png;*.jpg;*.bmp)', 'Audio (*.wav;*.ogg;*.mp3)', 'Scripts (*.ssl)']);
  cmbFilter.ItemIndex := 0; cmbFilter.OnChange := cmbFilterChange;

  btnBrowseFolder := TButton.Create(Self); btnBrowseFolder.Parent := pnlTop;
  btnBrowseFolder.Caption := '📁 Browse Folder...';
  btnBrowseFolder.Left := 244; btnBrowseFolder.Top := 28;
  btnBrowseFolder.Width := 130; btnBrowseFolder.Height := 28;
  btnBrowseFolder.OnClick := btnBrowseFolderClick;

  lblPath := TLabel.Create(Self); lblPath.Parent := pnlTop;
  lblPath.Left := 10; lblPath.Top := 52; lblPath.Caption := 'No folder selected';
  lblPath.Width := 600; lblPath.Font.Size := 7;

  pnlBottom := TPanel.Create(Self); pnlBottom.Parent := Self;
  pnlBottom.Align := alBottom; pnlBottom.Height := 42; pnlBottom.BevelOuter := bvNone;

  btnSelect := TButton.Create(Self); btnSelect.Parent := pnlBottom;
  btnSelect.Caption := 'Select'; btnSelect.Left := pnlBottom.Width - 196; btnSelect.Top := 7;
  btnSelect.Width := 88; btnSelect.Height := 28; btnSelect.Anchors := [akRight, akTop];
  btnSelect.OnClick := btnSelectClick;

  btnClose := TButton.Create(Self); btnClose.Parent := pnlBottom;
  btnClose.Caption := 'Cancel'; btnClose.ModalResult := mrCancel;
  btnClose.Left := pnlBottom.Width - 100; btnClose.Top := 7;
  btnClose.Width := 88; btnClose.Height := 28; btnClose.Anchors := [akRight, akTop];

  pnlList := TPanel.Create(Self); pnlList.Parent := Self;
  pnlList.Align := alLeft; pnlList.Width := 280; pnlList.BevelOuter := bvNone;

  tvAssets := TTreeView.Create(Self); tvAssets.Parent := pnlList;
  tvAssets.Align := alClient; tvAssets.OnClick := tvAssetsClick;

  splitter := TSplitter.Create(Self); splitter.Parent := Self;
  splitter.Align := alLeft; splitter.Width := 4;

  pnlPreview := TPanel.Create(Self); pnlPreview.Parent := Self;
  pnlPreview.Align := alClient; pnlPreview.BevelOuter := bvLowered;

  imgPreview := TImage.Create(Self); imgPreview.Parent := pnlPreview;
  imgPreview.Align := alClient; imgPreview.Stretch := True;
  imgPreview.Proportional := True; imgPreview.Center := True;
end;

procedure TAssetBrowserForm.StyleForm;
var t: TFDCTheme;
begin
  t := TThemeManager.Current;
  Color := t.BgDark; Font.Color := t.TextPrimary;
  pnlTop.Color := t.BgMedium; pnlBottom.Color := t.BgMedium;
  pnlList.Color := t.BgDark; pnlPreview.Color := t.BgLight;
  lblTitle.Font.Color := t.AccentPrimary;
  lblPath.Font.Color := t.TextDim;
  tvAssets.Color := t.BgDark; tvAssets.Font.Color := t.TextPrimary;
  cmbFilter.Color := t.BgLight;
end;

procedure TAssetBrowserForm.PopulateTree(const path: string);

  procedure AddDir(parent: TTreeNode; const dirPath: string);
  var
    dirs, files: TStringDynArray;
    node: TTreeNode;
  begin
    dirs := TDirectory.GetDirectories(dirPath);
    for var d in dirs do
    begin
      node := tvAssets.Items.AddChild(parent, ExtractFileName(d));
      node.Data := PChar(d);
      AddDir(node, d);
    end;
    files := TDirectory.GetFiles(dirPath);
    for var f in files do
    begin
      var ext := LowerCase(ExtractFileExt(f));
      if ext.IsEmpty then Continue;
      node := tvAssets.Items.AddChild(parent, ExtractFileName(f));
      node.Data := PChar(f);
    end;
  end;

begin
  tvAssets.Items.Clear;
  if not TDirectory.Exists(path) then Exit;
  lblPath.Caption := path;
  var root := tvAssets.Items.Add(nil, ExtractFileName(path));
  root.Data := PChar(path);
  AddDir(root, path);
  if tvAssets.Items.Count > 0 then tvAssets.Items[0].Expand(False);
end;

procedure TAssetBrowserForm.tvAssetsClick(Sender: TObject);
var
  node: TTreeNode;
  filePath: string;
  ext: string;
begin
  node := tvAssets.Selected;
  if not Assigned(node) or (node.Data = nil) then Exit;
  filePath := string(PChar(node.Data));
  if TFile.Exists(filePath) then
  begin
    FSelectedFile := filePath;
    lblPath.Caption := filePath;
    ext := LowerCase(ExtractFileExt(filePath));
    if (ext = '.png') or (ext = '.jpg') or (ext = '.jpeg') or (ext = '.bmp') then
    try
      imgPreview.Picture.LoadFromFile(filePath);
    except
      imgPreview.Picture.Assign(nil);
    end else
      imgPreview.Picture.Assign(nil);
  end;
end;

procedure TAssetBrowserForm.btnBrowseFolderClick(Sender: TObject);
var
  dlg: TFileOpenDialog;
begin
  dlg := TFileOpenDialog.Create(nil);
  try
    dlg.Options := [fdoPickFolders, fdoPathMustExist];
    dlg.Title := 'Select Asset Folder';
    if dlg.Execute then
    begin
      FRootPath := dlg.FileName;
      PopulateTree(FRootPath);
    end;
  finally dlg.Free; end;
end;

procedure TAssetBrowserForm.btnSelectClick(Sender: TObject);
begin
  if FSelectedFile <> '' then ModalResult := mrOk;
end;

procedure TAssetBrowserForm.cmbFilterChange(Sender: TObject);
begin
  if FRootPath <> '' then PopulateTree(FRootPath);
end;

initialization
  RegisterClass(TAssetBrowserForm);
end.
