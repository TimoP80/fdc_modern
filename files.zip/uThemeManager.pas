unit uThemeManager;

interface

uses
  Vcl.Graphics, Vcl.Controls, Vcl.Forms, Vcl.StdCtrls, Vcl.ComCtrls,
  Vcl.ExtCtrls, Vcl.Menus, System.SysUtils;

type
  TThemeStyle = (tsAmber, tsGreen, tsCyan, tsRed, tsWhite);

  TFDCTheme = record
    // Background colors
    BgDark: TColor;
    BgMedium: TColor;
    BgLight: TColor;
    // Accent/terminal colors
    AccentPrimary: TColor;
    AccentSecondary: TColor;
    AccentDim: TColor;
    // Text colors
    TextPrimary: TColor;
    TextSecondary: TColor;
    TextDim: TColor;
    TextDisabled: TColor;
    // Node canvas
    CanvasBg: TColor;
    GridColor: TColor;
    // Status colors
    ColorSuccess: TColor;
    ColorWarning: TColor;
    ColorError: TColor;
    ColorInfo: TColor;
    // Border colors
    BorderLight: TColor;
    BorderDark: TColor;
    // Font
    FontName: string;
    FontSize: Integer;
    MonoFontName: string;
    MonoFontSize: Integer;
    // Name
    StyleName: string;
  end;

  TThemeManager = class
  private
    class var FCurrentTheme: TFDCTheme;
    class var FCurrentStyle: TThemeStyle;
    class function GetAmberTheme: TFDCTheme;
    class function GetGreenTheme: TFDCTheme;
    class function GetCyanTheme: TFDCTheme;
    class function GetRedTheme: TFDCTheme;
    class function GetWhiteTheme: TFDCTheme;
  public
    class procedure ApplyTheme(style: TThemeStyle);
    class procedure ApplyToForm(form: TForm);
    class procedure ApplyToPanel(panel: TPanel);
    class procedure ApplyToMemo(memo: TMemo);
    class procedure ApplyToListBox(lb: TListBox);
    class procedure ApplyToTreeView(tv: TTreeView);
    class procedure ApplyToEdit(edit: TEdit);
    class procedure ApplyToLabel(lbl: TLabel);
    class procedure ApplyToButton(btn: TButton);
    class procedure ApplyToComboBox(cb: TComboBox);
    class function StyleName: string;
    class property Current: TFDCTheme read FCurrentTheme;
    class property CurrentStyle: TThemeStyle read FCurrentStyle;
  end;

implementation

class function TThemeManager.GetAmberTheme: TFDCTheme;
begin
  Result.StyleName := 'Amber Terminal';
  Result.BgDark := $00050302;
  Result.BgMedium := $000F0805;
  Result.BgLight := $001A1008;
  Result.AccentPrimary := $0020A0FF;   // Amber
  Result.AccentSecondary := $000060C0;  // Dim amber
  Result.AccentDim := $00003060;        // Very dim amber
  Result.TextPrimary := $0020B0FF;      // Bright amber text
  Result.TextSecondary := $000070AA;    // Mid amber
  Result.TextDim := $00003050;          // Dim amber
  Result.TextDisabled := $00002030;
  Result.CanvasBg := $00080503;
  Result.GridColor := $00100804;
  Result.ColorSuccess := $0040C040;
  Result.ColorWarning := $0000A0FF;
  Result.ColorError := $000040FF;
  Result.ColorInfo := $00C0C040;
  Result.BorderLight := $000050A0;
  Result.BorderDark := $00001020;
  Result.FontName := 'Segoe UI';
  Result.FontSize := 9;
  Result.MonoFontName := 'Courier New';
  Result.MonoFontSize := 9;
end;

class function TThemeManager.GetGreenTheme: TFDCTheme;
begin
  Result.StyleName := 'Green Phosphor';
  Result.BgDark := $00020502;
  Result.BgMedium := $00050F05;
  Result.BgLight := $00081A08;
  Result.AccentPrimary := $0030FF30;
  Result.AccentSecondary := $001A8A1A;
  Result.AccentDim := $00083008;
  Result.TextPrimary := $0040FF40;
  Result.TextSecondary := $00208020;
  Result.TextDim := $00083008;
  Result.TextDisabled := $00041804;
  Result.CanvasBg := $00030803;
  Result.GridColor := $00040C04;
  Result.ColorSuccess := $0040C040;
  Result.ColorWarning := $0000A0FF;
  Result.ColorError := $000040FF;
  Result.ColorInfo := $0060C0C0;
  Result.BorderLight := $00208020;
  Result.BorderDark := $00081008;
  Result.FontName := 'Segoe UI';
  Result.FontSize := 9;
  Result.MonoFontName := 'Courier New';
  Result.MonoFontSize := 9;
end;

class function TThemeManager.GetCyanTheme: TFDCTheme;
begin
  Result.StyleName := 'Cyan Digital';
  Result.BgDark := $00050808;
  Result.BgMedium := $000D1515;
  Result.BgLight := $00142222;
  Result.AccentPrimary := $00FFFF30;
  Result.AccentSecondary := $00909010;
  Result.AccentDim := $00303008;
  Result.TextPrimary := $00FFFF60;
  Result.TextSecondary := $00909030;
  Result.TextDim := $00303010;
  Result.TextDisabled := $00181808;
  Result.CanvasBg := $00080C0C;
  Result.GridColor := $000C1414;
  Result.ColorSuccess := $0040C040;
  Result.ColorWarning := $0000A0FF;
  Result.ColorError := $000040FF;
  Result.ColorInfo := $00C0C040;
  Result.BorderLight := $00609090;
  Result.BorderDark := $00101818;
  Result.FontName := 'Segoe UI';
  Result.FontSize := 9;
  Result.MonoFontName := 'Courier New';
  Result.MonoFontSize := 9;
end;

class function TThemeManager.GetRedTheme: TFDCTheme;
begin
  Result.StyleName := 'Red Alert';
  Result.BgDark := $00050202;
  Result.BgMedium := $000F0505;
  Result.BgLight := $001A0808;
  Result.AccentPrimary := $003040FF;
  Result.AccentSecondary := $001820A0;
  Result.AccentDim := $00080840;
  Result.TextPrimary := $004060FF;
  Result.TextSecondary := $002030A0;
  Result.TextDim := $00081040;
  Result.TextDisabled := $00040820;
  Result.CanvasBg := $00080303;
  Result.GridColor := $000C0404;
  Result.ColorSuccess := $0040C040;
  Result.ColorWarning := $0000A0FF;
  Result.ColorError := $000040FF;
  Result.ColorInfo := $00C0C040;
  Result.BorderLight := $002040A0;
  Result.BorderDark := $00081020;
  Result.FontName := 'Segoe UI';
  Result.FontSize := 9;
  Result.MonoFontName := 'Courier New';
  Result.MonoFontSize := 9;
end;

class function TThemeManager.GetWhiteTheme: TFDCTheme;
begin
  Result.StyleName := 'Vault-Tec White';
  Result.BgDark := $00181C20;
  Result.BgMedium := $00252C34;
  Result.BgLight := $00323C48;
  Result.AccentPrimary := $00D0A020;
  Result.AccentSecondary := $00906010;
  Result.AccentDim := $00402808;
  Result.TextPrimary := $00E8E8E0;
  Result.TextSecondary := $00B0B0A0;
  Result.TextDim := $00686858;
  Result.TextDisabled := $00383830;
  Result.CanvasBg := $00141820;
  Result.GridColor := $001C2028;
  Result.ColorSuccess := $0060C060;
  Result.ColorWarning := $0000B0FF;
  Result.ColorError := $000050FF;
  Result.ColorInfo := $00C0D000;
  Result.BorderLight := $00485060;
  Result.BorderDark := $00080C10;
  Result.FontName := 'Segoe UI';
  Result.FontSize := 9;
  Result.MonoFontName := 'Courier New';
  Result.MonoFontSize := 9;
end;

class procedure TThemeManager.ApplyTheme(style: TThemeStyle);
begin
  FCurrentStyle := style;
  case style of
    tsAmber: FCurrentTheme := GetAmberTheme;
    tsGreen: FCurrentTheme := GetGreenTheme;
    tsCyan:  FCurrentTheme := GetCyanTheme;
    tsRed:   FCurrentTheme := GetRedTheme;
    tsWhite: FCurrentTheme := GetWhiteTheme;
  end;
end;

class procedure TThemeManager.ApplyToForm(form: TForm);
begin
  form.Color := FCurrentTheme.BgDark;
  form.Font.Name := FCurrentTheme.FontName;
  form.Font.Size := FCurrentTheme.FontSize;
  form.Font.Color := FCurrentTheme.TextPrimary;
end;

class procedure TThemeManager.ApplyToPanel(panel: TPanel);
begin
  panel.Color := FCurrentTheme.BgMedium;
  panel.Font.Color := FCurrentTheme.TextPrimary;
  panel.Font.Name := FCurrentTheme.FontName;
  panel.ParentBackground := False;
  panel.BevelOuter := bvNone;
  panel.BevelInner := bvNone;
end;

class procedure TThemeManager.ApplyToMemo(memo: TMemo);
begin
  memo.Color := FCurrentTheme.BgDark;
  memo.Font.Color := FCurrentTheme.TextPrimary;
  memo.Font.Name := FCurrentTheme.MonoFontName;
  memo.Font.Size := FCurrentTheme.MonoFontSize;
end;

class procedure TThemeManager.ApplyToListBox(lb: TListBox);
begin
  lb.Color := FCurrentTheme.BgDark;
  lb.Font.Color := FCurrentTheme.TextPrimary;
  lb.Font.Name := FCurrentTheme.FontName;
end;

class procedure TThemeManager.ApplyToTreeView(tv: TTreeView);
begin
  tv.Color := FCurrentTheme.BgDark;
  tv.Font.Color := FCurrentTheme.TextPrimary;
  tv.Font.Name := FCurrentTheme.FontName;
end;

class procedure TThemeManager.ApplyToEdit(edit: TEdit);
begin
  edit.Color := FCurrentTheme.BgLight;
  edit.Font.Color := FCurrentTheme.TextPrimary;
  edit.Font.Name := FCurrentTheme.FontName;
end;

class procedure TThemeManager.ApplyToLabel(lbl: TLabel);
begin
  lbl.Font.Color := FCurrentTheme.AccentPrimary;
  lbl.Font.Name := FCurrentTheme.FontName;
end;

class procedure TThemeManager.ApplyToButton(btn: TButton);
begin
  btn.Font.Color := FCurrentTheme.TextPrimary;
  btn.Font.Name := FCurrentTheme.FontName;
end;

class procedure TThemeManager.ApplyToComboBox(cb: TComboBox);
begin
  cb.Color := FCurrentTheme.BgLight;
  cb.Font.Color := FCurrentTheme.TextPrimary;
  cb.Font.Name := FCurrentTheme.FontName;
end;

class function TThemeManager.StyleName: string;
begin
  Result := FCurrentTheme.StyleName;
end;

initialization
  TThemeManager.ApplyTheme(tsAmber);

end.
